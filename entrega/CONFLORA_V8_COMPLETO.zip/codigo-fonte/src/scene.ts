import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { state } from "./state";
import { t } from "./content";
import { planDiagram } from "./diagrams";
const C = {
  ivory: 0xeee8d9,
  wall: 0xe5dfcf,
  roof: 0x9c6045,
  wood: 0x80664a,
  dark: 0x163d33,
  grass: 0x718866,
  water: 0x72babc,
};
let seed = 241;
function rand() {
  seed = (seed * 16807) % 2147483647;
  return (seed - 1) / 2147483646;
}
const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
const materialCache = new Map<string, THREE.MeshStandardMaterial>();
const mat = (color: number, roughness = 0.85) => {
  const key = color + ":" + roughness;
  if (!materialCache.has(key))
    materialCache.set(
      key,
      new THREE.MeshStandardMaterial({ color, roughness }),
    );
  return materialCache.get(key)!;
};
function batch(g: THREE.Group, exclude: THREE.Object3D[] = []) {
  g.updateWorldMatrix(true, true);
  const inv = g.matrixWorld.clone().invert();
  const groups = new Map<
    THREE.Material,
    { geometry: THREE.BufferGeometry; mesh: THREE.Mesh }[]
  >();
  g.traverse((o) => {
    if (
      !(o instanceof THREE.Mesh) ||
      o instanceof THREE.InstancedMesh ||
      Array.isArray(o.material)
    )
      return;
    let parent: THREE.Object3D | null = o;
    while (parent) {
      if (exclude.includes(parent)) return;
      parent = parent.parent;
    }
    const geom = o.geometry
      .clone()
      .applyMatrix4(inv.clone().multiply(o.matrixWorld));
    const a = groups.get(o.material) || [];
    a.push({ geometry: geom, mesh: o });
    groups.set(o.material, a);
  });
  for (const [material, items] of groups) {
    if (items.length < 2) {
      items.forEach((i) => i.geometry.dispose());
      continue;
    }
    const geom = mergeGeometries(
      items.map((i) => i.geometry),
      false,
    );
    if (!geom) {
      items.forEach((i) => i.geometry.dispose());
      continue;
    }
    const merged = new THREE.Mesh(geom, material);
    merged.castShadow = true;
    merged.receiveShadow = true;
    g.add(merged);
    for (const i of items) {
      i.mesh.removeFromParent();
      i.mesh.geometry.dispose();
      i.geometry.dispose();
    }
  }
}
const materials = {
  wall: mat(C.wall),
  roof: mat(C.roof),
  wood: mat(C.wood),
  dark: mat(C.dark),
  glass: new THREE.MeshStandardMaterial({
    color: 0x244f4e,
    roughness: 0.2,
    metalness: 0.3,
  }),
  stone: mat(0xc1b9a5),
  cream: mat(0xe9e2d0),
};
function box(
  g: THREE.Object3D,
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  d: number,
  m: THREE.Material,
) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  g.add(mesh);
  return mesh;
}
function rod(
  g: THREE.Object3D,
  a: THREE.Vector3,
  b: THREE.Vector3,
  r: number,
  m: THREE.Material,
  r2 = r,
) {
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(r2, r, a.distanceTo(b), 6),
    m,
  );
  mesh.position.copy(a).add(b).multiplyScalar(0.5);
  mesh.quaternion.setFromUnitVectors(V(0, 1, 0), b.clone().sub(a).normalize());
  mesh.castShadow = true;
  g.add(mesh);
  return mesh;
}
function ellipse(
  g: THREE.Object3D,
  x: number,
  y: number,
  z: number,
  rx: number,
  rz: number,
  m: THREE.Material,
) {
  const mesh = new THREE.Mesh(new THREE.CircleGeometry(1, 64), m);
  mesh.rotation.x = -Math.PI / 2;
  mesh.scale.set(rx, rz, 1);
  mesh.position.set(x, y, z);
  mesh.receiveShadow = true;
  g.add(mesh);
  return mesh;
}
function makeTexture(type: "grass" | "soil" | "paving" | "wood") {
  const c = document.createElement("canvas");
  c.width = c.height = 256;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle =
    type === "grass"
      ? "#819174"
      : type === "soil"
        ? "#8c7558"
        : type === "wood"
          ? "#8c7658"
          : "#c4bfae";
  ctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 7000; i++) {
    const x = rand() * 256,
      y = rand() * 256;
    ctx.fillStyle =
      type === "grass"
        ? `rgba(${rand() > 0.5 ? "42,60,31" : "210,208,159"},${rand() * 0.16})`
        : type === "soil"
          ? `rgba(46,27,14,${rand() * 0.24})`
          : `rgba(77,69,52,${rand() * 0.13})`;
    ctx.fillRect(
      x,
      y,
      rand() * 2 + 1,
      type === "wood" ? rand() * 40 : rand() * 2 + 1,
    );
  }
  const tx = new THREE.CanvasTexture(c);
  tx.wrapS = tx.wrapT = THREE.RepeatWrapping;
  tx.repeat.set(type === "grass" ? 5 : 3, 4);
  tx.colorSpace = THREE.SRGBColorSpace;
  return tx;
}
function tree(g: THREE.Object3D, x: number, z: number, s: number) {
  const tree = new THREE.Group();
  tree.position.set(x, 0.05, z);
  tree.scale.setScalar(s);
  g.add(tree);
  rod(tree, V(0, 0, 0), V(0.12, 2.7, 0), 0.12, materials.wood, 0.045);
  const leaves = new THREE.InstancedMesh(
    new THREE.SphereGeometry(1, 6, 4),
    new THREE.MeshStandardMaterial({ color: 0x53754a, roughness: 0.95 }),
    520,
  );
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();
  for (let i = 0; i < 9; i++) {
    const ang = i * 2.4;
    const bx = Math.cos(ang) * (0.6 + rand() * 0.7),
      bz = Math.sin(ang) * (0.6 + rand() * 0.7),
      by = 2.2 + rand() * 1.3;
    rod(
      tree,
      V(0.04, 1.2 + i * 0.13, 0),
      V(bx, by, bz),
      0.045,
      materials.wood,
      0.013,
    );
    for (let j = 0; j < 57; j++) {
      const k = i * 57 + j;
      dummy.position.set(
        bx + (rand() - 0.5) * 1.4,
        by + (rand() - 0.5) * 1.25,
        bz + (rand() - 0.5) * 1.4,
      );
      dummy.scale.set(
        0.12 + rand() * 0.13,
        0.035 + rand() * 0.04,
        0.18 + rand() * 0.16,
      );
      dummy.rotation.set(rand() * 3, rand() * 6, rand() * 3);
      dummy.updateMatrix();
      leaves.setMatrixAt(k, dummy.matrix);
      color.setHSL(
        0.22 + rand() * 0.08,
        0.19 + rand() * 0.14,
        0.25 + rand() * 0.18,
      );
      leaves.setColorAt(k, color);
    }
  }
  leaves.count = 513;
  leaves.castShadow = true;
  tree.add(leaves);
  return tree;
}
function plantBed(
  g: THREE.Object3D,
  cx: number,
  cz: number,
  rx: number,
  rz: number,
  count: number,
  height = 0.65,
) {
  const leafMat = new THREE.MeshStandardMaterial({
    color: 0x648455,
    side: THREE.DoubleSide,
    roughness: 1,
  });
  const blade = new THREE.Shape();
  blade.moveTo(0, 0);
  blade.quadraticCurveTo(0.075, 0.4, 0.055, 0.8);
  blade.quadraticCurveTo(0.02, 0.5, 0, 0);
  const geo = new THREE.ShapeGeometry(blade, 4);
  const leaves = new THREE.InstancedMesh(geo, leafMat, count * 8);
  const flowers = new THREE.InstancedMesh(
    new THREE.SphereGeometry(0.034, 5, 4),
    mat(0xd7c595),
    count * 3,
  );
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();
  for (let i = 0; i < count; i++) {
    const ang = rand() * Math.PI * 2,
      r = Math.sqrt(rand()),
      x = cx + Math.cos(ang) * rx * r,
      z = cz + Math.sin(ang) * rz * r;
    for (let j = 0; j < 8; j++) {
      dummy.position.set(x, 0.04, z);
      dummy.rotation.set(
        (rand() - 0.5) * 0.5,
        rand() * Math.PI * 2,
        (rand() - 0.5) * 0.7,
      );
      dummy.scale.setScalar(height * (0.6 + rand() * 0.7));
      dummy.updateMatrix();
      leaves.setMatrixAt(i * 8 + j, dummy.matrix);
      color.setHSL(
        0.21 + rand() * 0.1,
        0.22 + rand() * 0.22,
        0.28 + rand() * 0.2,
      );
      leaves.setColorAt(i * 8 + j, color);
    }
    for (let j = 0; j < 3; j++) {
      dummy.position.set(
        x + (rand() - 0.5) * 0.15,
        height * (0.65 + rand() * 0.4),
        z + (rand() - 0.5) * 0.15,
      );
      dummy.rotation.set(0, 0, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      flowers.setMatrixAt(i * 3 + j, dummy.matrix);
      color.set([0xdec985, 0xc7b2a5, 0xe2ddbc, 0xa6ad83][i % 4]);
      flowers.setColorAt(i * 3 + j, color);
    }
  }
  leaves.castShadow = true;
  g.add(leaves, flowers);
  return g;
}
function house(g: THREE.Object3D) {
  const h = new THREE.Group();
  h.position.set(-2.6, 0, -2.3);
  g.add(h);
  box(h, 0, 1.35, 0, 4.5, 2.7, 3.7, materials.wall);
  box(h, 0, 0.11, 0, 4.7, 0.22, 3.9, materials.cream);
  const shape = new THREE.Shape()
    .moveTo(-2.5, 0)
    .lineTo(0, 1.55)
    .lineTo(2.5, 0)
    .lineTo(-2.5, 0);
  const roof = new THREE.Mesh(
    new THREE.ExtrudeGeometry(shape, { depth: 4.25, bevelEnabled: false }),
    materials.roof,
  );
  roof.position.set(0, 2.65, -2.125);
  roof.castShadow = true;
  h.add(roof);
  for (let i = 0; i < 28; i++) {
    const z = -2.12 + i * 0.158;
    rod(h, V(-2.53, 2.68, z), V(0, 4.24, z), 0.012, mat(0xb27c58));
    rod(h, V(0, 4.24, z), V(2.53, 2.68, z), 0.012, mat(0x92533c));
  }
  box(h, 0, 2.72, 1.97, 5.02, 0.11, 0.1, materials.dark);
  // Recessed glazing and fine timber facade.
  box(h, -0.6, 1.32, 1.865, 2.7, 1.95, 0.06, materials.dark);
  box(h, -0.6, 1.33, 1.905, 2.52, 1.77, 0.04, materials.glass);
  for (let i = 0; i < 4; i++)
    box(h, -1.8 + i * 0.8, 1.34, 1.95, 0.045, 1.9, 0.06, materials.wood);
  box(h, -0.6, 1.34, 1.95, 2.6, 0.035, 0.05, materials.wood);
  box(h, 1.55, 1.26, 1.875, 1, 2.35, 0.09, materials.wood);
  box(h, 1.85, 1.26, 1.94, 0.035, 0.16, 0.04, materials.cream);
  for (let i = 0; i < 27; i++)
    box(h, -2.17 + i * 0.164, 2.4, 1.91, 0.06, 0.38, 0.06, materials.wood);
  for (let j = 0; j < 2; j++) {
    box(h, 2.26, 1.48, -0.75 + j * 1.55, 0.06, 1.3, 0.9, materials.dark);
    box(h, 2.3, 1.48, -0.75 + j * 1.55, 0.025, 1.15, 0.75, materials.glass);
  }
  // Timber terrace, pergola and downpipe.
  box(h, 0, 0.1, 2.55, 5, 0.2, 1.4, materials.wood);
  for (let i = 0; i < 35; i++)
    box(h, -2.45 + i * 0.143, 0.21, 2.55, 0.008, 0.012, 1.4, materials.dark);
  box(h, -2.4, 1.43, 3.15, 0.09, 2.6, 0.09, materials.dark);
  box(h, 2.4, 1.43, 3.15, 0.09, 2.6, 0.09, materials.dark);
  for (let i = 0; i < 13; i++)
    box(h, -2.45 + i * 0.41, 2.79, 2.55, 0.055, 0.07, 1.4, materials.wood);
  rod(h, V(2.37, 2.7, 1.99), V(2.37, 0.15, 1.99), 0.038, materials.dark);
  rod(h, V(2.37, 0.15, 1.99), V(2.75, 0.12, 2.3), 0.04, materials.dark);
  // Bench and planters make the scale familiar.
  box(h, -0.65, 0.56, 2.7, 1.6, 0.1, 0.46, materials.cream);
  box(h, -1.25, 0.3, 2.7, 0.12, 0.5, 0.35, materials.dark);
  box(h, -0.05, 0.3, 2.7, 0.12, 0.5, 0.35, materials.dark);
  for (const x of [-2.1, 1.95]) {
    const pot = new THREE.Mesh(
      new THREE.CylinderGeometry(0.23, 0.17, 0.38, 12),
      mat(0xb18062),
    );
    pot.position.set(x, 0.38, 2.7);
    h.add(pot);
    plantBed(h, x, 2.7, 0.18, 0.18, 6, 0.8);
  }
  return h;
}
function curvedLine(
  g: THREE.Object3D,
  pts: number[][],
  color = 0x75c9cb,
  dashed = false,
) {
  const curve = new THREE.CatmullRomCurve3(pts.map((p) => V(p[0], p[1], p[2])));
  const geom = new THREE.BufferGeometry().setFromPoints(curve.getPoints(70));
  const m = dashed
    ? new THREE.LineDashedMaterial({
        color,
        dashSize: 0.15,
        gapSize: 0.12,
        transparent: true,
        opacity: 0.85,
      })
    : new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.8 });
  const line = new THREE.Line(geom, m);
  line.computeLineDistances();
  g.add(line);
  return { curve, line };
}
export class Landscape {
  host: HTMLElement;
  renderer: THREE.WebGLRenderer | null = null;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(34, 1, 0.1, 120);
  world = new THREE.Group();
  before = new THREE.Group();
  after = new THREE.Group();
  custom = new THREE.Group();
  flowsBefore = new THREE.Group();
  flowsAfter = new THREE.Group();
  infiltration = new THREE.Group();
  geology = new THREE.Group();
  surfaceMesh!: THREE.Mesh;
  groundMat!: THREE.MeshStandardMaterial;
  rainMesh!: THREE.LineSegments;
  rainPositions!: Float32Array;
  water!: THREE.Mesh;
  light!: THREE.DirectionalLight;
  ambient!: THREE.HemisphereLight;
  paths: { curve: THREE.CatmullRomCurve3; dot: THREE.Mesh; speed: number }[] =
    [];
  visible = true;
  frame = 0;
  last = 0;
  elapsed = 0;
  transition = 1;
  reduced = matchMedia("(prefers-reduced-motion: reduce)");
  needsDraw = true;
  fallback = false;
  onPlant: (x: number, z: number) => void;
  lastPlantSignature = "";
  lastSolution = "";
  lastSoil = "";
  lastSurface = "";
  size = { w: 1, h: 1 };
  observer: ResizeObserver;
  visibility: IntersectionObserver;
  constructor(host: HTMLElement, onPlant: (x: number, z: number) => void) {
    this.host = host;
    this.onPlant = onPlant;
    try {
      this.renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        powerPreference: "low-power",
      });
      this.renderer.setPixelRatio(Math.min(devicePixelRatio, 1.6));
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      this.renderer.outputColorSpace = THREE.SRGBColorSpace;
      this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
      this.renderer.toneMappingExposure = 1.35;
      this.renderer.setClearColor(0xe8e8df, 0);
      this.renderer.domElement.setAttribute("aria-hidden", "true");
      host.append(this.renderer.domElement);
      this.setup();
      this.renderer.domElement.addEventListener("click", (e) => this.click(e));
      this.renderer.domElement.addEventListener("webglcontextlost", (e) => {
        e.preventDefault();
        this.showFallback();
      });
    } catch {
      this.showFallback();
    }
    this.observer = new ResizeObserver(() => this.resize());
    this.observer.observe(host);
    this.visibility = new IntersectionObserver((e) => {
      this.visible = e[0].isIntersecting;
      if (this.visible) this.needsDraw = true;
    });
    this.visibility.observe(host);
    document.addEventListener("visibilitychange", () => {
      this.needsDraw = true;
    });
    this.reduced.addEventListener("change", () => {
      this.needsDraw = true;
    });
    this.resize();
    this.update();
    this.tick(0);
  }
  showFallback() {
    this.fallback = true;
    this.renderer?.domElement.remove();
    this.host.classList.add("fallback");
    this.host.innerHTML = `<p class="fallback-note">${t().webgl}</p><div id="fallback-diagram"></div>`;
    this.updateFallback();
  }
  updateFallback() {
    if (this.fallback) {
      const node = this.host.querySelector("#fallback-diagram");
      if (node)
        node.innerHTML = `<div class="fallback-visual"><div>${planDiagram(state.solution, true, true)}</div><div class="fallback-after" style="clip-path:inset(0 0 0 ${state.compare ? state.split : 0}%)">${planDiagram(state.solution, true)}</div></div>`;
      const note = this.host.querySelector(".fallback-note");
      if (note) note.textContent = t().webgl;
    }
  }
  setup() {
    seed = 241;
    this.scene.add(this.world);
    this.ambient = new THREE.HemisphereLight(0xf4f0de, 0x748577, 2.5);
    this.scene.add(this.ambient);
    this.light = new THREE.DirectionalLight(0xffebcd, 4);
    this.light.position.set(-7, 13, 6);
    this.light.castShadow = true;
    this.light.shadow.mapSize.set(2048, 2048);
    Object.assign(this.light.shadow.camera, {
      left: -11,
      right: 11,
      top: 10,
      bottom: -10,
      far: 40,
    });
    this.light.shadow.bias = -0.0008;
    this.light.shadow.normalBias = 0.035;
    this.scene.add(this.light);
    const fill = new THREE.DirectionalLight(0xc3dedb, 0.6);
    fill.position.set(9, 6, -4);
    this.scene.add(fill);
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(180, 180),
      new THREE.ShadowMaterial({ opacity: 0.12 }),
    );
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -1.3;
    ground.receiveShadow = true;
    this.scene.add(ground);
    this.groundMat = new THREE.MeshStandardMaterial({
      map: makeTexture("grass"),
      color: 0xd5d8bd,
      roughness: 1,
    });
    box(this.world, 0, -0.12, 0, 14, 0.26, 10, mat(0xa2967a));
    this.surfaceMesh = box(
      this.world,
      0,
      0.015,
      0,
      13.96,
      0.06,
      9.96,
      this.groundMat,
    );
    house(this.world);
    this.world.add(this.geology);
    const colors = [0x735b45, 0xb69b75, 0x877862];
    for (let i = 0; i < 3; i++) {
      const m = mat(colors[i]);
      m.map = makeTexture("soil");
      box(this.geology, 0, -0.33 - i * 0.24, 0, 13.98, 0.24, 9.98, m);
    }
    for (let i = 0; i < 150; i++) {
      const pebble = new THREE.Mesh(
        new THREE.IcosahedronGeometry(0.025 + rand() * 0.045, 0),
        mat(i % 2 ? 0xe2c8a0 : 0x5c5140),
      );
      pebble.position.set((rand() - 0.5) * 13.6, -0.35 - rand() * 0.5, 5.01);
      pebble.scale.set(1.4, 0.7, 0.5);
      this.geology.add(pebble);
    }
    // Narrow border, terraces, a gravel edge and timber fence.
    const gravelMat = mat(0xb3ac96);
    box(this.world, 6.65, 0.03, 0, 0.6, 0.08, 9.8, gravelMat);
    for (let i = 0; i < 400; i++) {
      const pebble = new THREE.Mesh(
        new THREE.IcosahedronGeometry(0.035 + rand() * 0.045, 0),
        i % 2 ? materials.stone : materials.cream,
      );
      pebble.position.set(6.4 + rand() * 0.5, 0.1, (rand() - 0.5) * 9.6);
      pebble.scale.y = 0.5;
      this.world.add(pebble);
    }
    for (let i = 0; i < 64; i++) {
      box(
        this.world,
        -6.7 + i * 0.21,
        0.68,
        -4.75,
        0.08,
        1.3,
        0.08,
        materials.wood,
      );
    }
    box(this.world, 0, 0.46, -4.77, 13.5, 0.06, 0.06, materials.wood);
    box(this.world, 0, 1, -4.77, 13.5, 0.06, 0.06, materials.wood);
    tree(this.world, 4.75, -2.8, 1.12);
    tree(this.world, -5.8, -3.15, 0.78);
    plantBed(this.world, 5.3, -3.8, 1, 0.6, 55, 0.6);
    plantBed(this.world, -5.9, -0.7, 0.65, 0.8, 30, 0.65);
    this.world.add(
      this.before,
      this.after,
      this.custom,
      this.flowsBefore,
      this.flowsAfter,
      this.infiltration,
    );
    box(this.before, 2.6, 0.055, 1.8, 5.1, 0.08, 4.2, mat(0xa9ad91));
    // Irregular grass blades around the fixed boundary, with no decorative wind loop.
    plantBed(this.world, 5.8, 3.7, 0.3, 0.75, 14, 0.45);
    const waterMat = new THREE.MeshStandardMaterial({
      color: C.water,
      transparent: true,
      opacity: 0.52,
      roughness: 0.18,
      metalness: 0.12,
      depthWrite: false,
    });
    this.water = ellipse(this.after, 2.5, 0.14, 1.9, 1.8, 1.15, waterMat);
    const route = (parent: THREE.Group, pts: number[][], dashed = false) => {
      const p = curvedLine(parent, pts, 0x519fa9, dashed);
      for (let i = 0; i < 5; i++) {
        const dot = new THREE.Mesh(
          new THREE.SphereGeometry(0.055, 6, 4),
          new THREE.MeshBasicMaterial({ color: 0xa1e3df }),
        );
        parent.add(dot);
        this.paths.push({ curve: p.curve, dot, speed: i / 5 });
      }
      return p;
    };
    route(this.flowsBefore, [
      [-0.15, 2.8, -0.3],
      [-0.15, 0.2, 0.2],
      [0.1, 0.14, 1.6],
      [1.2, 0.14, 3.4],
      [2.7, 0.14, 4.8],
    ]);
    route(this.flowsBefore, [
      [-4, 0.2, 1],
      [-3.5, 0.15, 2.3],
      [-3, 0.15, 3.5],
      [-2.3, 0.15, 4.85],
    ]);
    route(this.flowsAfter, [
      [-0.15, 2.8, -0.3],
      [-0.15, 0.2, 0.2],
      [0.7, 0.16, 0.9],
      [1.7, 0.16, 1.6],
      [2.5, 0.17, 1.9],
    ]);
    route(
      this.flowsAfter,
      [
        [2.5, 0.18, 1.9],
        [3.9, 0.18, 2.8],
        [4.7, 0.17, 3.8],
        [5.1, 0.14, 4.9],
      ],
      true,
    );
    for (const x of [1.65, 2.65, 3.5])
      route(
        this.infiltration,
        [
          [x, 0.1, 2],
          [x + 0.1, -0.4, 2],
          [x - 0.1, -0.9, 2],
          [x + 0.15, -1.3, 2],
        ],
        true,
      );
    const max = 500;
    this.rainPositions = new Float32Array(max * 6);
    for (let i = 0; i < max; i++) {
      const x = (rand() - 0.5) * 14,
        y = rand() * 8 + 0.2,
        z = (rand() - 0.5) * 10;
      this.rainPositions.set([x, y, z, x - 0.06, y + 0.25, z], i * 6);
    }
    const rainGeo = new THREE.BufferGeometry();
    rainGeo.setAttribute(
      "position",
      new THREE.BufferAttribute(this.rainPositions, 3),
    );
    this.rainMesh = new THREE.LineSegments(
      rainGeo,
      new THREE.LineBasicMaterial({
        color: 0x4b969f,
        transparent: true,
        opacity: 0.52,
        depthWrite: false,
      }),
    );
    this.world.add(this.rainMesh);
    batch(this.geology);
    batch(this.world, [
      this.geology,
      this.before,
      this.after,
      this.custom,
      this.flowsBefore,
      this.flowsAfter,
      this.infiltration,
      this.rainMesh,
    ]);
  }
  buildFlowRoutes() {
    this.paths = this.paths.filter(
      (p) =>
        p.dot.parent !== this.flowsAfter && p.dot.parent !== this.infiltration,
    );
    this.disposeGroup(this.flowsAfter);
    this.disposeGroup(this.infiltration);
    const sol = state.solution;
    const inlet: number[][] =
      sol === "strip"
        ? [
            [-0.15, 2.8, -0.3],
            [-0.15, 0.2, 0.2],
            [0.7, 0.17, 1.5],
            [1.6, 0.17, 3.1],
            [3.5, 0.17, 3.2],
          ]
        : sol === "swale"
          ? [
              [-0.15, 2.8, -0.3],
              [-0.15, 0.2, 0.2],
              [1.2, 0.17, -0.1],
              [3.2, 0.17, -0.6],
              [3.3, 0.17, 2.8],
            ]
          : sol === "permeable"
            ? [
                [-0.15, 2.8, -0.3],
                [-0.15, 0.2, 0.2],
                [0.8, 0.25, 0.3],
                [1.6, 0.25, 1.3],
                [2.3, 0.25, 2.3],
              ]
            : [
                [-0.15, 2.8, -0.3],
                [-0.15, 0.2, 0.2],
                [0.7, 0.16, 0.9],
                [1.7, 0.16, 1.6],
                [2.5, 0.17, 1.9],
              ];
    const end = inlet[inlet.length - 1];
    const outlet = [end, [4.3, 0.2, 3.6], [5.1, 0.14, 4.9]];
    const add = (parent: THREE.Group, pts: number[][], dashed = false) => {
      const p = curvedLine(parent, pts, 0x519fa9, dashed);
      for (let i = 0; i < 5; i++) {
        const dot = new THREE.Mesh(
          new THREE.SphereGeometry(0.055, 6, 4),
          new THREE.MeshBasicMaterial({ color: 0xa1e3df }),
        );
        parent.add(dot);
        this.paths.push({ curve: p.curve, dot, speed: i / 5 });
      }
    };
    add(this.flowsAfter, inlet);
    add(this.flowsAfter, outlet, true);
    for (const offset of [-0.6, 0, 0.6]) {
      const x = (sol === "swale" ? 3.35 : 2.5) + offset,
        z = sol === "strip" ? 3.2 : sol === "permeable" ? 1.75 : 1.9;
      add(
        this.infiltration,
        [
          [x, 0.1, z],
          [x + 0.1, -0.4, z],
          [x - 0.1, -0.9, z],
          [x + 0.15, -1.3, z],
        ],
        true,
      );
    }
  }
  resize() {
    const r = this.host.getBoundingClientRect();
    if (!r.width || !r.height) return;
    this.size = { w: r.width, h: r.height };
    if (this.renderer) {
      this.renderer.setSize(r.width, r.height);
      this.camera.aspect = r.width / r.height;
      const dist =
        this.camera.aspect < 1 ? 1.38 : this.camera.aspect < 1.5 ? 1.14 : 1;
      this.camera.position.set(13.2 * dist, 11.8 * dist, 18 * dist);
      this.camera.lookAt(0.1, 0.5, 0.1);
      this.camera.updateProjectionMatrix();
      this.needsDraw = true;
    }
  }
  disposeGroup(g: THREE.Group) {
    for (const c of [...g.children]) {
      g.remove(c);
      c.traverse((o) => {
        if (o instanceof THREE.Mesh || o instanceof THREE.Line) {
          o.geometry.dispose();
          const ms = Array.isArray(o.material) ? o.material : [o.material];
          for (const m of ms) {
            if (
              !Object.values(materials).includes(
                m as THREE.MeshStandardMaterial,
              ) &&
              ![...materialCache.values()].includes(
                m as THREE.MeshStandardMaterial,
              )
            )
              m.dispose();
          }
        }
      });
    }
  }
  buildSolution() {
    this.disposeGroup(this.after);
    seed = 742;
    const sol = state.solution;
    const soil = mat(0x786149);
    const gravel = mat(0xc0b59b);
    let cx = 2.65,
      cz = 1.9,
      rx = 2,
      rz = 1.5,
      count = 180;
    if (sol === "strip") {
      cx = 2.65;
      cz = 3.2;
      rx = 2.6;
      rz = 0.65;
      count = 145;
    }
    if (sol === "swale") {
      cx = 3.35;
      cz = 1.5;
      rx = 0.85;
      rz = 2.65;
      count = 125;
    }
    if (sol !== "permeable") {
      ellipse(this.after, cx, 0.09, cz, rx + 0.17, rz + 0.17, gravel);
      ellipse(this.after, cx, 0.105, cz, rx, rz, soil);
      for (let i = 0; i < 75; i++) {
        const a = (i / 75) * Math.PI * 2;
        const stone = new THREE.Mesh(
          new THREE.IcosahedronGeometry(0.06 + rand() * 0.04, 0),
          i % 3 ? materials.stone : materials.cream,
        );
        stone.position.set(
          cx + Math.cos(a) * (rx + 0.07),
          0.12,
          cz + Math.sin(a) * (rz + 0.07),
        );
        stone.scale.y = 0.6;
        this.after.add(stone);
      }
      plantBed(
        this.after,
        cx,
        cz,
        rx * 0.98,
        rz * 0.97,
        count,
        sol === "strip" ? 0.75 : 0.85,
      );
    } else {
      box(this.after, 2.5, 0.1, 1.75, 5.1, 0.12, 4.3, mat(0x778b6b));
      for (let x = 0; x < 9; x++)
        for (let z = 0; z < 8; z++) {
          box(
            this.after,
            0.08 + x * 0.57,
            0.19,
            -0.24 + z * 0.54,
            0.5,
            0.13,
            0.46,
            z % 2 ? materials.cream : materials.stone,
          );
        }
      plantBed(this.after, 5.4, 2.5, 0.33, 1.5, 40, 0.65);
    }
    const waterMat = new THREE.MeshStandardMaterial({
      color: C.water,
      transparent: true,
      opacity: 0.5,
      roughness: 0.12,
      metalness: 0.15,
      depthWrite: false,
    });
    this.water = ellipse(
      this.after,
      cx,
      0.13,
      cz,
      rx * 0.83,
      rz * 0.8,
      waterMat,
    );
    batch(this.after, [this.water]);
    this.transition = this.reduced.matches || state.paused ? 1 : 0;
  }
  buildSurface() {
    const old = this.before.getObjectByName("surface");
    if (old) this.before.remove(old);
    const oldBase = this.world.getObjectByName("common-surface");
    if (oldBase) {
      this.disposeGroup(oldBase as THREE.Group);
      this.world.remove(oldBase);
    }
    const m = new THREE.MeshStandardMaterial({
      color:
        state.surface === "paved"
          ? 0xb8b5a6
          : state.surface === "bare"
            ? 0x9d8563
            : 0x9da580,
      map: makeTexture(
        state.surface === "paved"
          ? "paving"
          : state.surface === "bare"
            ? "soil"
            : "grass",
      ),
      roughness: 1,
    });
    const g = new THREE.Group();
    g.name = "common-surface";
    box(g, -3.1, 0.075, 2.7, 5.5, 0.08, 4.45, m);
    if (state.surface === "paved")
      for (let i = 0; i < 6; i++)
        box(g, -5.8 + i * 1.1, 0.12, 2.7, 0.015, 0.006, 4.4, mat(0x918e80));
    this.world.add(g);
  }
  update() {
    this.needsDraw = true;
    this.updateFallback();
    if (this.fallback) return;
    if (state.paused) this.transition = 1;
    if (this.lastSolution !== state.solution) {
      this.lastSolution = state.solution;
      this.buildSolution();
      this.buildFlowRoutes();
    }
    if (this.lastSurface !== state.surface) {
      this.lastSurface = state.surface;
      this.buildSurface();
    }
    if (this.lastPlantSignature !== JSON.stringify(state.plants)) {
      this.lastPlantSignature = JSON.stringify(state.plants);
      this.disposeGroup(this.custom);
      for (const p of state.plants)
        plantBed(this.custom, p.x, p.z, 0.2, 0.2, 9, 1);
    }
    this.light.color.set(state.dusk ? 0xe9b28a : 0xffebcd);
    this.light.intensity = state.dusk ? 2.4 : 4;
    this.ambient.intensity = state.dusk ? 1.9 : 2.5;
    this.host.classList.toggle("dusk", state.dusk);
    this.host.classList.toggle("planting", state.planting);
    this.geology.scale.y = state.xray ? 1.8 : 1;
    this.water.visible = state.rain > 0;
    const wm = this.water.material as THREE.MeshStandardMaterial;
    wm.opacity =
      state.soil === "slow" ? 0.7 : state.soil === "unknown" ? 0.4 : 0.25;
    this.rainMesh.geometry.setDrawRange(
      0,
      state.rain * [0, 75, 140, 165][state.rain] * 2,
    );
    this.rainMesh.visible = state.rain > 0;
  }
  click(e: MouseEvent) {
    if (!state.planting || this.fallback) return;
    const r = this.host.getBoundingClientRect();
    const pointer = new THREE.Vector2(
      ((e.clientX - r.left) / r.width) * 2 - 1,
      (-(e.clientY - r.top) / r.height) * 2 + 1,
    );
    const ray = new THREE.Raycaster();
    ray.setFromCamera(pointer, this.camera);
    const p = new THREE.Vector3();
    ray.ray.intersectPlane(new THREE.Plane(V(0, 1, 0), -0.15), p);
    if (p.x > -0.1 && p.x < 6.2 && p.z > -0.5 && p.z < 4.5)
      this.onPlant(p.x, p.z);
  }
  tick = (time: number) => {
    requestAnimationFrame(this.tick);
    if (this.fallback || !this.renderer || !this.visible || document.hidden)
      return;
    const dt = Math.min((time - this.last) / 1000, 0.05);
    this.last = time;
    const moving = !this.reduced.matches && !state.paused;
    if (
      !this.needsDraw &&
      (!moving || state.rain === 0) &&
      this.transition >= 1
    )
      return;
    if (time - this.frame < 32) return;
    this.frame = time;
    if (moving) this.elapsed += dt;
    this.transition = Math.min(1, this.transition + dt * 2.4);
    this.after.position.y = -((1 - this.transition) ** 2) * 0.65;
    this.after.scale.y = 0.65 + 0.35 * this.transition;
    if (moving && state.rain > 0) {
      for (let i = 0; i < this.rainPositions.length; i += 6) {
        this.rainPositions[i + 1] -= dt * (4 + state.rain);
        if (this.rainPositions[i + 1] < 0.2)
          this.rainPositions[i + 1] = 7 + rand();
        this.rainPositions[i + 4] = this.rainPositions[i + 1] + 0.22;
      }
      this.rainMesh.geometry.attributes.position.needsUpdate = true;
    }
    for (const p of this.paths) {
      p.dot.position.copy(
        p.curve.getPointAt((this.elapsed * 0.15 + p.speed) % 1),
      );
    }
    const wet = state.rain > 0 && state.flow;
    this.flowsBefore.visible = wet;
    this.flowsAfter.visible = wet;
    this.infiltration.visible = wet && state.xray && state.soil !== "slow";
    this.infiltration.traverse((o) => {
      if (o instanceof THREE.Line)
        (o.material as THREE.LineBasicMaterial).opacity =
          state.soil === "unknown" ? 0.35 : 0.8;
    });
    this.renderer.setScissorTest(false);
    this.renderer.clear();
    const render = (after: boolean) => {
      this.before.visible = !after;
      this.after.visible = after;
      this.custom.visible = after;
      this.flowsBefore.visible = wet && !after;
      this.flowsAfter.visible = wet && after;
      this.infiltration.visible =
        wet && after && state.xray && state.soil !== "slow";
      this.renderer!.render(this.scene, this.camera);
    };
    if (state.compare) {
      const split = Math.round((this.size.w * state.split) / 100);
      this.renderer.setScissorTest(true);
      this.renderer.setScissor(0, 0, split, this.size.h);
      render(false);
      this.renderer.setScissor(split, 0, this.size.w - split, this.size.h);
      render(true);
      this.renderer.setScissorTest(false);
    } else render(true);
    this.needsDraw = false;
  };
  capture() {
    if (!this.renderer) return "";
    this.needsDraw = true;
    this.renderer.render(this.scene, this.camera);
    return this.renderer.domElement.toDataURL("image/png");
  }
}

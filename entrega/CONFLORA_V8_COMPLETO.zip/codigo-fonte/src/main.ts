import "./fonts.css";
import "./style.css";
import {
  state,
  restore,
  persist,
  type Solution,
  type Soil,
  type Surface,
} from "./state";
import { t } from "./content";
import { renderLayout } from "./layout";
import { icon } from "./diagrams";
import { Landscape } from "./scene";
import {
  renderPlanner,
  renderReport,
  changePlan,
  validate,
  summaryText,
  downloadFile,
  exportKit,
} from "./planner";
restore();
const root = document.querySelector("#app")!;
const landscapeHost = document.createElement("div");
landscapeHost.id = "landscape";
landscapeHost.className = "landscape";
let landscape: Landscape;
let guideStep = -1;
let toastTimer: ReturnType<typeof setTimeout>;
let previousLanguageFocus = false;
function render() {
  const l = t();
  document.documentElement.lang = state.lang === "pt" ? "pt-BR" : "en";
  document.title = `CONFLORA — ${l.atelier}`;
  landscapeHost.remove();
  root.innerHTML = `${renderLayout()}`;
  const slot = document.querySelector("#landscape-slot")!;
  slot.replaceWith(landscapeHost);
  landscapeHost.setAttribute("role", "img");
  landscapeHost.setAttribute("aria-label", l.sceneLabel);
  renderPlanner();
  renderReport();
  updateLab();
  renderGuide();
  if (previousLanguageFocus) {
    document
      .querySelector<HTMLButtonElement>(`[data-lang="${state.lang}"]`)
      ?.focus();
    previousLanguageFocus = false;
  }
}
function updateLab() {
  const l = t();
  const rainWords = [l.rainOff, l.rainLight, l.rainMedium, l.rainHeavy];
  const output = document.querySelector("#rain-value");
  if (!output) return;
  output.textContent = rainWords[state.rain];
  const range = document.querySelector("#rain") as HTMLInputElement;
  range.value = String(state.rain);
  range.setAttribute("aria-valuetext", rainWords[state.rain]);
  document.querySelector("#rain-button-text")!.textContent = state.rain
    ? l.stopRain
    : l.startRain;
  const checked: Record<string, boolean> = {
    compare: state.compare,
    xray: state.xray,
    flow: state.flow,
    pause: state.paused,
    dusk: state.dusk,
    "plant-mode": state.planting,
  };
  for (const [k, v] of Object.entries(checked)) {
    const b = document.querySelector(`[data-action="${k}"]`);
    b?.setAttribute("aria-pressed", String(v));
  }
  const pause = document.querySelector('[data-action="pause"]')!;
  pause.innerHTML =
    icon(state.paused ? "play" : "pause") +
    `<span>${state.paused ? l.resume : l.pause}</span>`;
  pause.setAttribute("aria-label", state.paused ? l.resume : l.pause);
  const dusk = document.querySelector('[data-action="dusk"]')!;
  dusk.innerHTML = icon("sun") + `<span>${state.dusk ? l.day : l.dusk}</span>`;
  dusk.setAttribute("aria-label", state.dusk ? l.day : l.dusk);
  (document.querySelector("#compare-track") as HTMLElement).hidden =
    !state.compare;
  (document.querySelector("#compare-hint") as HTMLElement).hidden =
    !state.compare;
  document
    .querySelector("#before-label")!
    .classList.toggle("hidden", !state.compare);
  document
    .querySelector("#after-label")!
    .classList.toggle("hidden", !state.compare);
  (document.querySelector("#divider") as HTMLElement).style.left =
    state.split + "%";
  (document.querySelector("#split") as HTMLInputElement).value = String(
    state.split,
  );
  (document.querySelector("#soil-caption") as HTMLElement).hidden = !state.xray;
  (document.querySelector("#hypothesis-label") as HTMLElement).hidden =
    state.soil !== "unknown";
  document
    .querySelectorAll<HTMLElement>('[data-action="solution"]')
    .forEach((b) =>
      b.setAttribute(
        "aria-pressed",
        String(b.dataset.value === state.solution),
      ),
    );
  document.querySelector("#observation-title")!.textContent = l[state.solution];
  document.querySelector("#solution-description")!.textContent = String(
    l[(state.solution + "Desc") as keyof typeof l],
  );
  document.querySelector("#water-observation")!.textContent =
    state.rain === 0
      ? l.dryText
      : state.rain === 3
        ? l.heavyText
        : state.soil === "slow"
          ? l.slowText
          : state.soil === "unknown"
            ? l.unknownText
            : l.wetText;
  document.querySelector("#plant-count")!.textContent =
    `${l.plantCount}: ${state.plants.length}`;
  landscape?.update();
}
function scrollToId(id: string, focus?: string) {
  document
    .getElementById(id)
    ?.scrollIntoView({
      behavior: matchMedia("(prefers-reduced-motion: reduce)").matches
        ? "instant"
        : "smooth",
      block: "start",
    });
  if (focus) document.getElementById(focus)?.focus({ preventScroll: true });
}
function toast(text: string) {
  const node = document.querySelector("#toast")!;
  node.textContent = text;
  node.classList.add("visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => node.classList.remove("visible"), 3500);
}
function renderGuide() {
  const el = document.querySelector("#guide") as HTMLElement;
  if (!el) return;
  el.hidden = guideStep < 0;
  if (guideStep < 0) return;
  const l = t();
  el.innerHTML = `<span class="guide-count">0${guideStep + 1}/04</span><div><strong>${l.guideSteps[guideStep]}</strong><p>${l.guideNote[guideStep]}</p></div><button class="text-link" data-action="guide-next">${guideStep === 3 ? l.finishGuide : l.next}${icon("arrow")}</button><button class="icon-button" data-action="guide-close" aria-label="${l.close}">${icon("close")}</button>`;
}
function setGuideStep(i: number) {
  guideStep = i;
  if (i === 0) state.rain = 2;
  if (i === 2) state.compare = true;
  if (i === 3) state.xray = true;
  renderGuide();
  updateLab();
}
function carry() {
  state.plan.solution = state.solution;
  state.plan.soil = state.soil;
  state.report = false;
  persist();
  renderPlanner();
  renderReport();
  document.querySelector("#plan-preview strong")!.textContent =
    t()[state.plan.solution];
  scrollToId("planner", "step-title");
}
render();
landscape = new Landscape(landscapeHost, (x, z) => {
  if (state.plants.length >= 18) state.plants.shift();
  state.plants.push({ x, z });
  updateLab();
});
root.addEventListener("click", async (e) => {
  const button = (e.target as Element).closest<HTMLElement>("[data-action]");
  if (!button) return;
  const a = button.dataset.action,
    v = button.dataset.value,
    l = t();
  switch (a) {
    case "lang":
      previousLanguageFocus = true;
      state.lang = button.dataset.lang as "pt" | "en";
      persist();
      render();
      break;
    case "rain":
      state.rain = state.rain ? 0 : 2;
      updateLab();
      break;
    case "solution":
      state.solution = v as Solution;
      state.plan.solution = state.solution;
      state.report = false;
      persist();
      renderReport();
      document.querySelector("#plan-preview strong")!.textContent =
        l[state.solution];
      if (state.step === 2) renderPlanner();
      updateLab();
      break;
    case "compare":
      state.compare = !state.compare;
      updateLab();
      break;
    case "xray":
      state.xray = !state.xray;
      updateLab();
      break;
    case "flow":
      state.flow = !state.flow;
      updateLab();
      break;
    case "pause":
      state.paused = !state.paused;
      updateLab();
      break;
    case "dusk":
      state.dusk = !state.dusk;
      updateLab();
      break;
    case "reset":
      Object.assign(state, {
        rain: 0,
        solution: "garden",
        soil: "unknown",
        surface: "paved",
        compare: false,
        split: 50,
        xray: false,
        flow: true,
        paused: false,
        dusk: false,
        planting: false,
        plants: [],
      });
      state.plan.solution = "garden";
      state.plan.soil = "unknown";
      state.report = false;
      persist();
      (document.querySelector("#soil") as HTMLSelectElement).value = state.soil;
      (document.querySelector("#surface") as HTMLSelectElement).value =
        state.surface;
      renderPlanner();
      renderReport();
      document.querySelector("#plan-preview strong")!.textContent = l.garden;
      guideStep = -1;
      renderGuide();
      updateLab();
      break;
    case "fullscreen":
      try {
        const el = document.querySelector(".landscape-panel") as HTMLElement;
        if (document.fullscreenElement) await document.exitFullscreen();
        else await el.requestFullscreen();
      } catch {
        toast(
          state.lang === "pt"
            ? "Use o zoom do navegador para ampliar a paisagem."
            : "Use browser zoom to enlarge the landscape.",
        );
      }
      break;
    case "plant-mode":
      state.planting = !state.planting;
      updateLab();
      break;
    case "add-plant":
      if (state.plants.length >= 18) state.plants.shift();
      state.plants.push({
        x: 1 + (state.plants.length % 5) * 0.8,
        z: 1 + Math.floor(state.plants.length / 5) * 0.7,
      });
      updateLab();
      break;
    case "clear-plants":
      state.plants = [];
      updateLab();
      break;
    case "carry":
      carry();
      break;
    case "guide":
      setGuideStep(0);
      break;
    case "guide-next":
      if (guideStep < 3) setGuideStep(guideStep + 1);
      else {
        guideStep = -1;
        renderGuide();
        document
          .querySelector<HTMLButtonElement>('[data-action="guide"]')
          ?.focus();
      }
      break;
    case "guide-close":
      guideStep = -1;
      renderGuide();
      document
        .querySelector<HTMLButtonElement>('[data-action="guide"]')
        ?.focus();
      break;
    case "layer":
      state.layer = Number(v);
      document
        .querySelector("#soil-illustration")!
        .setAttribute("data-layer", String(state.layer));
      document.querySelectorAll('[data-action="layer"]').forEach((b, i) => {
        b.setAttribute("aria-expanded", String(i === state.layer));
        b.querySelector(".layer-plus")!.textContent =
          i === state.layer ? "−" : "+";
        (document.querySelector(`#layer-detail-${i}`) as HTMLElement).hidden =
          i !== state.layer;
      });
      break;
    case "plan-next":
      if (!validate()) return;
      if (state.step < 3) {
        state.step++;
        renderPlanner();
        document.getElementById("step-title")?.focus({ preventScroll: true });
      } else {
        state.report = true;
        renderReport();
        scrollToId("report", "report-title");
      }
      break;
    case "plan-back":
      state.step = Math.max(0, state.step - 1);
      renderPlanner();
      document.getElementById("step-title")?.focus({ preventScroll: true });
      break;
    case "step":
      if (Number(v) > state.step && !validate()) return;
      state.step = Number(v);
      renderPlanner();
      document.getElementById("step-title")?.focus({ preventScroll: true });
      break;
    case "clear-plan":
      try {
        localStorage.removeItem("conflora-atelier-v8");
      } catch {
        /* Storage may be unavailable. */
      }
      Object.assign(state.plan, {
        country: "BR",
        property: "home",
        area: "",
        source: "roof",
        soil: "unknown",
        slope: "unknown",
        sun: "unknown",
        moisture: "unknown",
        goal: "understand",
        risks: ["unknown"],
        solution: "garden",
      });
      state.feedback = { score: "", comment: "" };
      state.soil = "unknown";
      state.solution = "garden";
      state.step = 0;
      state.report = false;
      render();
      document.querySelector<HTMLInputElement>('[name="area"]')?.focus();
      break;
    case "print":
      window.print();
      break;
    case "download-plan":
      downloadFile(`conflora-roteiro-${state.lang}.txt`, summaryText());
      break;
    case "copy":
      try {
        await navigator.clipboard.writeText(summaryText());
        toast(l.copied);
      } catch {
        toast(l.copyFailed);
      }
      break;
    case "edit":
      state.report = false;
      renderReport();
      scrollToId("planner", "step-title");
      break;
    case "feedback":
      state.feedback.score = v!;
      document
        .querySelectorAll<HTMLElement>('[data-action="feedback"]')
        .forEach((b) =>
          b.setAttribute("aria-pressed", String(b.dataset.value === v)),
        );
      break;
    case "export-feedback":
      downloadFile(
        `conflora-feedback-${state.lang}.txt`,
        [
          l.feedbackTitle,
          state.feedback.score
            ? l.feedbackOptions[Number(state.feedback.score)]
            : "—",
          l.feedbackComment,
          state.feedback.comment || "—",
          l.feedbackPrivacy,
        ].join("\n"),
      );
      break;
    case "export-kit":
      exportKit();
      break;
  }
});
root.addEventListener("input", (e) => {
  const el = e.target as HTMLInputElement;
  if (el.id === "rain") {
    state.rain = Number(el.value);
    updateLab();
  }
  if (el.id === "split") {
    state.split = Number(el.value);
    updateLab();
  }
  if (el.name === "area") {
    changePlan("area", el.value);
    el.removeAttribute("aria-invalid");
    (document.querySelector("#area-error") as HTMLElement).hidden = true;
  }
  if (el.id === "feedback-comment") state.feedback.comment = el.value;
});
root.addEventListener("change", (e) => {
  const el = e.target as HTMLInputElement;
  if (el.id === "soil") {
    state.soil = el.value as Soil;
    state.plan.soil = state.soil;
    persist();
    state.report = false;
    renderReport();
    if (state.step === 1) renderPlanner();
    updateLab();
  }
  if (el.id === "surface") {
    state.surface = el.value as Surface;
    updateLab();
  }
  if (el.closest("#planner-body") && el.name) {
    changePlan(el.name, el.value, el.checked);
    if (el.name === "soil") {
      state.soil = el.value as Soil;
      (document.querySelector("#soil") as HTMLSelectElement).value = el.value;
      updateLab();
    }
    if (el.name === "solution") {
      state.solution = el.value as Solution;
      document.querySelector("#plan-preview strong")!.textContent =
        t()[state.solution];
      updateLab();
    }
    state.report = false;
    renderReport();
  }
});
addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    if (state.planting) {
      state.planting = false;
      updateLab();
    }
    if (guideStep >= 0) {
      guideStep = -1;
      renderGuide();
    }
  }
});
addEventListener("fullscreenchange", () => {
  const b = document.querySelector('[data-action="fullscreen"]');
  const label = document.fullscreenElement
    ? t().exitFullscreen
    : t().fullscreen;
  b?.setAttribute("aria-label", label);
  const span = b?.querySelector("span");
  if (span) span.textContent = label;
});

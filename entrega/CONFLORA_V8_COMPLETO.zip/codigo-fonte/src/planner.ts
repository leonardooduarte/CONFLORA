import {
  state,
  persist,
  riskReasons,
  escapeHtml as esc,
  type Plan,
} from "./state";
import { t, sources } from "./content";
import { icon, planDiagram } from "./diagrams";
function label(key: string) {
  const l = t() as unknown as Record<string, unknown>;
  return String(l[key] || key);
}
export function select(name: keyof Plan, title: string, values: string[]) {
  return `<label class="field">${title}<select name="${name}">${values.map((v) => `<option value="${v}" ${state.plan[name] === v ? "selected" : ""}>${esc(label(v))}</option>`).join("")}</select></label>`;
}
export function renderPlanner() {
  const l = t(),
    p = state.plan;
  const host = document.querySelector("#planner-body");
  if (!host) return;
  let html = "";
  if (state.step === 0) {
    html = `<div class="form-grid">${select("country", l.region, ["BR", "US"])}${select("property", l.property, ["home", "school", "rural"])}<label class="field">${l.area}<input name="area" type="number" inputmode="decimal" min="0.01" max="100000" step="any" required value="${esc(p.area)}" aria-describedby="area-hint area-error"><small id="area-hint">${l.areaHint}</small></label>${select("source", l.source, ["roof", "yard", "path", "field"])}</div>`;
  } else if (state.step === 1) {
    html = `<div class="form-grid">${select("soil", l.soil, ["unknown", "draining", "slow"])}${select("slope", l.slope, ["unknown", "flat", "steep"])}${select("sun", l.sun, ["unknown", "shade", "mixed", "sunny"])}${select("moisture", l.moisture, ["unknown", "dry", "variable", "wet"])}</div><p class="form-note">${icon("info")}${l.soilNote}</p>`;
  } else if (state.step === 2) {
    html = `${select("goal", l.goal, ["understand", "runoff", "biodiversity", "learn"])}<fieldset class="solution-field"><legend>${l.selectedSolution}</legend><div class="plan-solutions">${(["garden", "strip", "swale", "permeable"] as const).map((s, i) => `<label class="radio-line"><input type="radio" name="solution" value="${s}" ${p.solution === s ? "checked" : ""}><span class="radio-index">0${i + 1}</span><span>${l[s]}</span></label>`).join("")}</div></fieldset><p class="form-note">${icon("info")}${l.intentNote}</p>`;
  } else {
    const names: Record<string, string> = {
      well: l.well,
      pollution: l.pollution,
      house: l.house,
      none: l.none,
      unknown: l.riskUnknown,
    };
    html = `<fieldset class="risk-field"><legend>${l.risks}</legend>${Object.entries(
      names,
    )
      .map(
        ([v, s]) =>
          `<label class="check-line"><input type="checkbox" name="risks" value="${v}" ${p.risks.includes(v) ? "checked" : ""}><span>${s}</span></label>`,
      )
      .join(
        "",
      )}</fieldset><p class="form-note warning">${icon("info")}${l.riskHint}</p>`;
  }
  host.innerHTML = `<div class="step-top"><span class="eyebrow">${l.step} 0${state.step + 1} / 04</span><h3 tabindex="-1" id="step-title">${l.stepNames[state.step]}</h3></div>${html}<p id="area-error" class="form-error" role="alert" hidden></p><div class="form-actions"><button type="button" class="button quiet" data-action="plan-back" ${state.step === 0 ? "disabled" : ""}>${l.back}</button><button type="button" class="button dark" data-action="plan-next">${state.step === 3 ? l.generate : l.continue}${icon("arrow")}</button></div>`;
  document.querySelectorAll("[data-step]").forEach((el, i) => {
    el.classList.toggle("active", i === state.step);
    el.classList.toggle("complete", i < state.step);
    if (i === state.step) el.setAttribute("aria-current", "step");
    else el.removeAttribute("aria-current");
  });
}
export function validate() {
  const l = t();
  if (state.step === 0) {
    const a = Number(state.plan.area);
    if (!state.plan.area || !Number.isFinite(a) || a <= 0 || a > 100000) {
      const e = document.querySelector("#area-error") as HTMLElement;
      e.hidden = false;
      e.textContent = l.validation;
      const input = document.querySelector('[name="area"]') as HTMLInputElement;
      input.setAttribute("aria-invalid", "true");
      input.focus();
      return false;
    }
  }
  if (state.step === 3 && !state.plan.risks.length) {
    const e = document.querySelector("#area-error") as HTMLElement;
    e.hidden = false;
    e.textContent = l.requiredRisk;
    return false;
  }
  return true;
}
export function changePlan(name: string, value: string, checked?: boolean) {
  const p = state.plan;
  if (name === "risks") {
    if (value === "none" || value === "unknown")
      p.risks = checked ? [value] : [];
    else {
      p.risks = p.risks.filter(
        (x) => x !== "none" && x !== "unknown" && x !== value,
      );
      if (checked) p.risks.push(value);
    }
    document
      .querySelectorAll<HTMLInputElement>('[name="risks"]')
      .forEach((el) => (el.checked = p.risks.includes(el.value)));
  } else if (name in p) (p as unknown as Record<string, unknown>)[name] = value;
  persist();
}
export function summaryRows() {
  const l = t(),
    p = state.plan;
  const list: [string, string][] = [
    [l.region, label(p.country)],
    [l.property, label(p.property)],
    [l.area, `${p.area} m²`],
    [l.source, label(p.source)],
    [l.soil, label(p.soil)],
    [l.slope, label(p.slope)],
    [l.sun, label(p.sun)],
    [l.moisture, label(p.moisture)],
    [l.goal, label(p.goal)],
    [l.selectedSolution, label(p.solution)],
  ];
  return list;
}
export function summaryText() {
  const l = t(),
    risk = riskReasons().length > 0;
  return [
    l.reportKicker,
    l.reportSub,
    "",
    l.reported,
    ...summaryRows().map(([k, v]) => `${k}: ${v}`),
    "",
    l.risks,
    ...state.plan.risks.map((r) => label(r === "unknown" ? "riskUnknown" : r)),
    "",
    risk ? l.reportRisk : l.reportStudy,
    risk ? l.reportRiskText : l.reportStudyText,
    "",
    l[(state.plan.solution + "Desc") as keyof typeof l] as string,
    "",
    l.components,
    ...l.componentLists[state.plan.solution].map((v) => "- " + v),
    "",
    l.stepsTitle,
    ...l.stepsList.map((v, i) => `${i + 1}. ${v}`),
    "",
    l.reportLimits,
    "",
    ...sources,
  ].join("\n");
}
export function renderReport() {
  const host = document.querySelector("#report") as HTMLElement;
  if (!host) return;
  host.hidden = !state.report;
  if (!state.report) return;
  const l = t(),
    p = state.plan,
    risk = riskReasons().length > 0;
  const date = new Date().toLocaleDateString(
    state.lang === "pt" ? "pt-BR" : "en-US",
    {
      timeZone: "America/Sao_Paulo",
      year: "numeric",
      month: "long",
      day: "numeric",
    },
  );
  host.innerHTML = `<article class="report-sheet"><div class="report-top"><span class="eyebrow">${l.reportKicker}</span><span>№ 001 / ${p.country}</span></div><div class="report-heading"><div><h2 tabindex="-1" id="report-title">${l.reportTitle}</h2><p>${l.reportSub}</p><small>${l.date} ${date}</small></div><div class="report-stamp">C<span>FIELD<br>NOTES</span></div></div><div class="report-status ${risk ? "risk" : ""}"><strong>${icon("info")}${risk ? l.reportRisk : l.reportStudy}</strong><p>${risk ? l.reportRiskText : l.reportStudyText}</p></div><div class="report-overview"><div><h3 class="eyebrow">${l.reported}</h3><dl>${summaryRows()
    .map(([k, v]) => `<div><dt>${k}</dt><dd>${esc(v)}</dd></div>`)
    .join(
      "",
    )}<div><dt>${l.risks}</dt><dd>${p.risks.map((r) => esc(label(r === "unknown" ? "riskUnknown" : r))).join("; ")}</dd></div></dl></div><div class="report-plan"><span class="eyebrow">${l.concept}</span>${planDiagram(p.solution)}<h3>${l[p.solution]}</h3><p>${l[(p.solution + "Desc") as keyof typeof l]}</p></div></div><div class="report-columns"><section><h3>${l.components}</h3><ul>${l.componentLists[p.solution].map((x) => `<li>${x}</li>`).join("")}</ul></section><section><h3>${l.stepsTitle}</h3><ol>${l.stepsList.map((x) => `<li>${x}</li>`).join("")}</ol></section></div><p class="report-limit">${l.reportLimits}</p><div class="report-references">${sources.map((s, i) => `<a href="${s}" target="_blank" rel="noopener noreferrer">${l.refTitles[i]}</a>`).join(" · ")}</div><div class="report-actions"><button class="button dark" data-action="print">${icon("print")}${l.print}</button><button class="button outline" data-action="download-plan">${icon("download")}${l.download}</button><button class="button quiet" data-action="copy">${icon("copy")}${l.copy}</button><button class="button quiet" data-action="edit">${l.edit}</button></div></article><div class="feedback"><h3>${l.feedbackTitle}</h3><div class="feedback-options">${l.feedbackOptions.map((s, i) => `<button data-action="feedback" data-value="${i}" aria-pressed="${state.feedback.score === String(i)}">${s}</button>`).join("")}</div><label class="field">${l.feedbackComment}<textarea id="feedback-comment" rows="2" maxlength="2000">${esc(state.feedback.comment)}</textarea></label><div class="feedback-bottom"><small>${l.feedbackPrivacy}</small><button class="text-link" data-action="export-feedback">${l.exportFeedback} ↓</button></div></div>`;
}
export function downloadFile(
  name: string,
  content: string,
  type = "text/plain;charset=utf-8",
) {
  const blob = new Blob([type.startsWith("text/") ? "\uFEFF" : "", content], {
    type,
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
export function exportKit() {
  downloadFile(
    `conflora-kit-studio-${state.lang}.json`,
    JSON.stringify(
      {
        schema: "conflora-kit-context/1",
        purpose:
          "Educational context only; not a commercial order or installation design",
        language: state.lang,
        providedByUser: state.plan,
        requiresSpecialistAssessment: riskReasons().length > 0,
        scientificLimitations: t().reportLimits,
        integrationStatus: "in-development",
        sources,
      },
      null,
      2,
    ),
    "application/json",
  );
}

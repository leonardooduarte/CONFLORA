import { chromium } from "playwright";
import AxeBuilder from "@axe-core/playwright";
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { existsSync } from "node:fs";
const project = path.resolve(new URL("..", import.meta.url).pathname);
const out = path.resolve(
  process.env.TEST_OUTPUT || path.join(project, "test-results"),
);
await fs.mkdir(out, { recursive: true });
const results = [];
const errors = [];
const accessibility = [];
let browser;
const hash = (b) => crypto.createHash("sha256").update(b).digest("hex");
const check = (b, m) => {
  if (!b) throw new Error(m);
};
async function test(name, fn) {
  const start = Date.now();
  try {
    await fn();
    results.push({ name, status: "passed", durationMs: Date.now() - start });
    console.log("PASS", name);
  } catch (e) {
    results.push({
      name,
      status: "failed",
      error: String(e),
      durationMs: Date.now() - start,
    });
    console.log("FAIL", name, String(e));
  }
}
async function makePage(
  b = browser,
  size = { width: 1440, height: 1000 },
  options = {},
) {
  const context = await b.newContext({
    viewport: size,
    deviceScaleFactor: 1,
    acceptDownloads: true,
    hasTouch: size.width < 600,
    isMobile: size.width < 600,
    ...options,
  });
  await context.route("https://conflora.test/**", async (route) => {
    const u = new URL(route.request().url());
    const target = path.join(
      project,
      "dist",
      u.pathname === "/" ? "index.html" : decodeURIComponent(u.pathname),
    );
    if (!target.startsWith(path.join(project, "dist"))) {
      return route.fulfill({ status: 403, body: "Forbidden" });
    }
    try {
      await route.fulfill({ path: target });
    } catch {
      await route.fulfill({ status: 404, body: "Not found" });
    }
  });
  const page = await context.newPage();
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto("https://conflora.test/", { waitUntil: "networkidle" });
  await page.locator("#rain").waitFor();
  await page.evaluate(() => document.fonts.ready);
  return { page, context };
}
const click = (p, a) => p.locator(`[data-action="${a}"]`).first().click();
const shot = (p, name, fullPage = false) =>
  p.screenshot({ path: path.join(out, name + ".png"), fullPage });
const canvasHash = async (p) =>
  hash(await p.locator("#landscape").screenshot());
const range = async (p, id, value) => {
  const el = p.locator("#" + id);
  await el.focus();
  await el.press("Home");
  for (let i = 0; i < value; i++) await el.press("ArrowRight");
};
browser = await chromium.launch({
  headless: true,
  executablePath:
    process.env.CHROMIUM_PATH ||
    (existsSync("/usr/bin/chromium")
      ? "/usr/bin/chromium"
      : chromium.executablePath()),
  args: ["--no-sandbox", "--enable-unsafe-swiftshader"],
});
const { page, context } = await makePage();
await test("Desktop: 3D real, primeira interação e captura", async () => {
  check(
    (await page.locator("#landscape canvas").count()) === 1,
    "3D canvas missing",
  );
  await shot(page, "01-desktop-inicial");
  await click(page, "rain");
  check(
    (await page.locator("#rain-value").textContent()) === "Moderada",
    "Rain did not start",
  );
  await shot(page, "02-desktop-chuva");
});
await test("Intensidade acessível por teclado: sem chuva, leve, moderada e intensa", async () => {
  for (let i = 0; i < 4; i++) {
    await range(page, "rain", i);
    check(
      (await page.locator("#rain-value").textContent()) ===
        ["Sem chuva", "Leve", "Moderada", "Intensa"][i],
      `Wrong rain ${i}`,
    );
  }
  check(
    (await page.locator("#water-observation").textContent()).includes(
      "superar",
    ),
    "Missing overflow explanation",
  );
});
await test("Solo e superfície alteram o estado e as explicações", async () => {
  await page.locator(".conditions summary").click();
  await page.locator("#soil").selectOption("slow");
  await range(page, "rain", 2);
  check(
    (await page.locator("#water-observation").textContent()).includes(
      "drenagem lenta",
    ),
    "Slow soil text missing",
  );
  await page.locator("#surface").selectOption("bare");
  check(
    (await page.locator("#surface").inputValue()) === "bare",
    "Bare soil not selected",
  );
  await click(page, "xray");
  check(
    await page.locator("#soil-caption").isVisible(),
    "Soil section not open",
  );
  check(
    await page.locator("#hypothesis-label").isHidden(),
    "Known slow soil should not show infiltration hypothesis",
  );
  await page.locator("#soil").selectOption("unknown");
  check(
    await page.locator("#hypothesis-label").isVisible(),
    "Unknown soil needs a hypothesis label",
  );
  await shot(page, "03-corte-do-solo");
  await page.locator(".conditions summary").click();
});
await test("Quatro intervenções com geometria diferente e estado compartilhado", async () => {
  await range(page, "rain", 0);
  await click(page, "pause");
  const hashes = [];
  for (const s of ["garden", "strip", "swale", "permeable"]) {
    await page.locator(`[data-action="solution"][data-value="${s}"]`).click();
    check(
      (await page
        .locator(`[data-action="solution"][data-value="${s}"]`)
        .getAttribute("aria-pressed")) === "true",
      "Selection not updated",
    );
    await page.waitForTimeout(100);
    hashes.push(await canvasHash(page));
  }
  check(new Set(hashes).size === 4, "Solutions did not alter the scene");
  await shot(page, "04-piso-permeavel");
});
await test("Comparador contínuo por teclado altera a imagem nos extremos", async () => {
  await page.locator('[data-action="solution"][data-value="garden"]').click();
  await click(page, "compare");
  const slider = page.locator("#split");
  await slider.focus();
  await slider.press("Home");
  const after = await canvasHash(page);
  await slider.press("End");
  const before = await canvasHash(page);
  check(before !== after, "Comparison images are identical");
  await slider.press("Home");
  for (let i = 0; i < 50; i++) await slider.press("ArrowRight");
  check((await slider.inputValue()) === "50", "Keyboard comparator mismatch");
  await range(page, "rain", 2);
  await shot(page, "05-comparacao-antes-depois");
});
await test("Percursos, pausa, luz e reinício possuem comportamento", async () => {
  await click(page, "flow");
  check(
    (await page
      .locator('[data-action="flow"]')
      .getAttribute("aria-pressed")) === "false",
    "Flow did not switch",
  );
  await click(page, "dusk");
  check(
    await page
      .locator("#landscape")
      .getAttribute("class")
      .then((c) => c.includes("dusk")),
    "Dusk not applied",
  );
  await click(page, "reset");
  check(
    (await page.locator("#rain").inputValue()) === "0",
    "Reset rain failed",
  );
  check(await page.locator("#split").isHidden(), "Reset comparison failed");
});
await test("Tela cheia nativa abre e fecha a mesma paisagem", async () => {
  await click(page, "fullscreen");
  await page.waitForTimeout(100);
  check(
    await page.evaluate(() => !!document.fullscreenElement),
    "Fullscreen did not open",
  );
  await click(page, "fullscreen");
  check(
    !(await page.evaluate(() => !!document.fullscreenElement)),
    "Fullscreen did not close",
  );
});
await test("Plantio com alternativa de teclado e remoção", async () => {
  await page.locator(".plant-details summary").click();
  await click(page, "add-plant");
  check(
    (await page.locator("#plant-count").textContent()).endsWith("1"),
    "Plant not added",
  );
  await click(page, "plant-mode");
  check(
    (await page
      .locator('[data-action="plant-mode"]')
      .getAttribute("aria-pressed")) === "true",
    "Plant mode missing",
  );
  await page.keyboard.press("Escape");
  check(
    (await page
      .locator('[data-action="plant-mode"]')
      .getAttribute("aria-pressed")) === "false",
    "Escape failed",
  );
  await click(page, "plant-mode");
  const c = await page.locator("#landscape canvas").boundingBox();
  await page
    .locator("#landscape canvas")
    .click({ position: { x: c.width * 0.6, y: c.height * 0.62 } });
  check(
    (await page.locator("#plant-count").textContent()).endsWith("2"),
    "Scene pointer planting failed",
  );
  await click(page, "clear-plants");
  check(
    (await page.locator("#plant-count").textContent()).endsWith("0"),
    "Plants not cleared",
  );
  await page.keyboard.press("Escape");
});
await test("Guia funcional percorre chuva, comparação e solo", async () => {
  await click(page, "guide");
  for (let i = 0; i < 3; i++) await click(page, "guide-next");
  check(
    (await page
      .locator('[data-action="xray"]')
      .getAttribute("aria-pressed")) === "true",
    "Guide soil failed",
  );
  await click(page, "guide-next");
  check(await page.locator("#guide").isHidden(), "Guide not closed");
});
await test("Anatomia: todos os cinco componentes abrem e mudam destaque", async () => {
  for (let i = 0; i < 5; i++) {
    await page.locator(`[data-action="layer"][data-value="${i}"]`).click();
    check(
      await page.locator(`#layer-detail-${i}`).isVisible(),
      "Missing layer content",
    );
    check(
      (await page.locator("#soil-illustration").getAttribute("data-layer")) ===
        String(i),
      "Diagram layer mismatch",
    );
  }
  await shot(page, "06-anatomia");
});
await test("Transferência de solução e solo ao planejador", async () => {
  await page.locator(".conditions summary").click();
  await page.locator("#soil").selectOption("slow");
  await page.locator('[data-action="solution"][data-value="swale"]').click();
  await click(page, "carry");
  check(
    (await page.locator("#plan-preview strong").textContent()) ===
      "Vala vegetada",
    "Solution not carried",
  );
  await click(page, "plan-next");
  check(
    (await page.locator('[name="soil"]').inputValue()) === "slow",
    "Soil not carried",
  );
});
await test("Validação de área impede avanço inválido e leva foco ao campo", async () => {
  await click(page, "plan-back");
  for (const value of ["", "0", "-5", "100001"]) {
    await page.locator('[name="area"]').fill(value);
    await click(page, "plan-next");
    check(
      await page.locator("#area-error").isVisible(),
      "Invalid area accepted",
    );
    check(
      (await page.locator('[name="area"]').getAttribute("aria-invalid")) ===
        "true",
      "Field not marked invalid",
    );
  }
  await page.locator('[name="area"]').fill("24.5");
  await click(page, "plan-next");
  check(
    (await page.locator('[name="soil"]').count()) === 1,
    "Valid area rejected",
  );
});
await test("Planejador completo PT, riscos exclusivos e relatório coerente", async () => {
  await page.locator('[name="sun"]').selectOption("mixed");
  await page.locator('[name="moisture"]').selectOption("wet");
  await page.locator('[name="slope"]').selectOption("steep");
  await click(page, "plan-next");
  await page.locator('[name="goal"]').selectOption("biodiversity");
  await page.locator('[name="solution"][value="strip"]').check();
  await click(page, "plan-next");
  await page.locator('[name="risks"][value="well"]').check();
  check(
    !(await page.locator('[name="risks"][value="unknown"]').isChecked()),
    "Mutually exclusive risk not cleared",
  );
  await page.locator('[name="risks"][value="pollution"]').check();
  await click(page, "plan-next");
  await page.locator("#report-title").waitFor();
  check(
    (await page.locator(".report-status.risk").count()) === 1,
    "Risk warning missing",
  );
  const text = await page.locator("#report").textContent();
  for (const s of [
    "24.5 m²",
    "Faixa vegetada",
    "Sol e sombra",
    "Frequentemente úmida",
    "Avaliação especializada necessária",
    "não é um projeto executivo",
  ])
    check(text.includes(s), `Report missing ${s}`);
  await shot(page, "07-relatorio-portugues", true);
});
await test("Exportações reais: TXT, JSON do kit e avaliação", async () => {
  let wait = page.waitForEvent("download");
  await click(page, "download-plan");
  let d = await wait;
  await d.saveAs(path.join(out, "exemplo-roteiro-pt.txt"));
  check(
    (await fs.readFile(await d.path(), "utf8")).includes("24.5 m²"),
    "TXT missing answers",
  );
  wait = page.waitForEvent("download");
  await click(page, "export-kit");
  d = await wait;
  await d.saveAs(path.join(out, "exemplo-kit-studio.json"));
  const json = JSON.parse(await fs.readFile(await d.path(), "utf8"));
  check(
    json.providedByUser.solution === "strip" &&
      json.integrationStatus === "in-development",
    "Kit JSON mismatch",
  );
  await page.locator('[data-action="feedback"][data-value="0"]').click();
  await page
    .locator("#feedback-comment")
    .fill("Precisamos discutir a vegetação regional.");
  wait = page.waitForEvent("download");
  await click(page, "export-feedback");
  d = await wait;
  await d.saveAs(path.join(out, "exemplo-avaliacao.txt"));
  check(
    (await fs.readFile(await d.path(), "utf8")).includes("vegetação regional"),
    "Feedback export failed",
  );
});
await test("Impressão real e PDF A4 contêm apenas o relatório", async () => {
  let printCalled = false;
  await page.exposeFunction("recordPrint", () => {
    printCalled = true;
  });
  await page.evaluate(() => {
    window.print = () => window.recordPrint();
  });
  await click(page, "print");
  check(printCalled, "Print button did not invoke printing");
  await page.emulateMedia({ media: "print" });
  check(await page.locator(".header").isHidden(), "Header would print");
  check(
    await page.locator(".report-sheet").isVisible(),
    "Report hidden in print",
  );
  await page.pdf({
    path: path.join(out, "exemplo-relatorio-pt.pdf"),
    format: "A4",
    printBackground: true,
    preferCSSPageSize: true,
  });
  await page.emulateMedia({ media: "screen" });
});
await test("Cópia de resumo usa a área de transferência ou informa a alternativa", async () => {
  await context.grantPermissions(["clipboard-read", "clipboard-write"], {
    origin: "https://conflora.test",
  });
  await click(page, "copy");
  const toast = await page.locator("#toast").textContent();
  check(
    toast === "Resumo copiado." || toast.includes("download"),
    "Copy has no accessible outcome",
  );
  if (toast === "Resumo copiado.")
    check(
      (await page.evaluate(() => navigator.clipboard.readText())).includes(
        "24.5 m²",
      ),
      "Clipboard missing site answers",
    );
});
await test("Troca completa para inglês com relatório e opções traduzidos", async () => {
  await page.locator('[data-action="lang"][data-lang="en"]').click();
  check(
    (await page.locator("html").getAttribute("lang")) === "en",
    "English lang missing",
  );
  check(
    (await page.locator("#report").textContent()).includes(
      "Specialist assessment needed",
    ),
    "Report not translated",
  );
  check(
    (await page.locator("#report").textContent()).includes("Sun and shade"),
    "Sun not translated",
  );
  check(
    (await page.locator("#report").textContent()).includes("Vegetated buffer"),
    "Solution not translated",
  );
  await page.locator(".conditions summary").click();
  check(
    (await page.locator('#soil option[value="slow"]').textContent()) === "Slow",
    "Conditions not translated",
  );
  await shot(page, "08-desktop-english");
});
await test("Persistência local de idioma e respostas após recarga", async () => {
  await page.reload({ waitUntil: "networkidle" });
  check(
    (await page.locator("html").getAttribute("lang")) === "en",
    "Language not persisted",
  );
  check(
    (await page.locator('[name="area"]').inputValue()) === "24.5",
    "Area not persisted",
  );
  await click(page, "plan-next");
  check(
    (await page.locator('[name="sun"]').inputValue()) === "mixed",
    "Sun not persisted",
  );
});
await test("Jornada EN completa e estado sem riscos identificados exige revisão", async () => {
  await page.locator('[name="soil"]').selectOption("draining");
  await page.locator('[name="slope"]').selectOption("flat");
  await click(page, "plan-next");
  await page.locator('[name="solution"][value="permeable"]').check();
  await click(page, "plan-next");
  await page.locator('[name="risks"][value="none"]').check();
  check(
    !(await page.locator('[name="risks"][value="well"]').isChecked()),
    "Exclusive none failed",
  );
  await click(page, "plan-next");
  check(
    (await page.locator(".report-status").textContent()).includes(
      "A concept to investigate",
    ),
    "Wrong status",
  );
  check(
    (await page.locator(".report-status").textContent()).includes(
      "professional review",
    ),
    "Missing mandatory review",
  );
  await page.emulateMedia({ media: "print" });
  await page.pdf({
    path: path.join(out, "exemplo-relatorio-en.pdf"),
    format: "A4",
    printBackground: true,
    preferCSSPageSize: true,
  });
  await page.emulateMedia({ media: "screen" });
});
await test("Acessibilidade automatizada desktop: WCAG 2 A/AA e 2.1 A/AA", async () => {
  const r = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"])
    .analyze();
  accessibility.push({ viewport: "desktop", violations: r.violations });
  check(
    r.violations.length === 0,
    r.violations
      .map((x) => `${x.id}: ${x.nodes.map((n) => n.target).join(", ")}`)
      .join("\n"),
  );
});
await test("Celular, tablet e desktop: sem rolagem horizontal e capturas reais", async () => {
  for (const [name, w, h] of [
    ["mobile-390", 390, 844],
    ["mobile-360", 360, 800],
    ["mobile-320", 320, 700],
    ["tablet-768", 768, 1024],
    ["tablet-1024", 1024, 768],
    ["desktop-1920", 1920, 1080],
  ]) {
    const p = await makePage(browser, { width: w, height: h });
    check(
      !(await p.page.evaluate(
        () => document.documentElement.scrollWidth > innerWidth,
      )),
      `${name} has horizontal overflow`,
    );
    await shot(p.page, `09-${name}`);
    if (w === 390) {
      await click(p.page, "rain");
      await p.page
        .locator('[data-action="solution"][data-value="permeable"]')
        .tap();
      await click(p.page, "compare");
      const sr = await p.page.locator("#split").boundingBox();
      await p.page.touchscreen.tap(
        sr.x + sr.width * 0.72,
        sr.y + sr.height * 0.5,
      );
      check(
        Number(await p.page.locator("#split").inputValue()) > 50,
        "Touch comparison did not move",
      );
      await shot(p.page, "10-mobile-interacao", true);
      await click(p.page, "carry");
      for (let i = 0; i < 4; i++) await click(p.page, "plan-next");
      check(
        await p.page.locator("#report-title").isVisible(),
        "Mobile report failed",
      );
      await shot(p.page, "11-mobile-relatorio", true);
      const r = await new AxeBuilder({ page: p.page })
        .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"])
        .analyze();
      accessibility.push({ viewport: "mobile", violations: r.violations });
      check(!r.violations.length, r.violations.map((v) => v.id).join(", "));
    }
    await p.context.close();
  }
});
await test("Movimento reduzido: cena continua estável e controles funcionam", async () => {
  const p = await makePage(
    browser,
    { width: 1280, height: 900 },
    { reducedMotion: "reduce" },
  );
  await click(p.page, "rain");
  const a = await canvasHash(p.page);
  await p.page.waitForTimeout(350);
  const b = await canvasHash(p.page);
  check(a === b, "Reduced-motion rain still animates");
  await p.page.locator('[data-action="solution"][data-value="strip"]').click();
  check(
    a !== (await canvasHash(p.page)),
    "Reduced-motion scene not interactive",
  );
  await p.context.close();
});
await test("Sem WebGL: esquema interativo, comparação e planejamento", async () => {
  const b = await chromium.launch({
    headless: true,
    executablePath:
      process.env.CHROMIUM_PATH ||
      (existsSync("/usr/bin/chromium")
        ? "/usr/bin/chromium"
        : chromium.executablePath()),
    args: ["--no-sandbox", "--disable-webgl"],
  });
  const p = await makePage(b);
  check(await p.page.locator(".fallback-note").isVisible(), "Fallback missing");
  await click(p.page, "rain");
  await click(p.page, "compare");
  await range(p.page, "split", 25);
  check(
    (await p.page.locator(".fallback-after").getAttribute("style")).includes(
      "25%",
    ),
    "Fallback comparison did not respond",
  );
  await p.page.locator('[data-action="solution"][data-value="swale"]').click();
  await click(p.page, "carry");
  check(
    await p.page.locator("#planner-body").isVisible(),
    "Fallback planner unavailable",
  );
  await shot(p.page, "12-sem-webgl");
  await p.context.close();
  await b.close();
});
await test("Armazenamento bloqueado: aplicação e apagamento continuam utilizáveis", async () => {
  const ctx = await browser.newContext();
  await ctx.addInitScript(() => {
    Storage.prototype.getItem = () => {
      throw Error("Storage denied");
    };
    Storage.prototype.setItem = () => {
      throw Error("Storage denied");
    };
    Storage.prototype.removeItem = () => {
      throw Error("Storage denied");
    };
  });
  await ctx.route("https://conflora.test/**", async (r) =>
    r.fulfill({
      path: path.join(
        project,
        "dist",
        new URL(r.request().url()).pathname === "/"
          ? "index.html"
          : new URL(r.request().url()).pathname,
      ),
    }),
  );
  const p = await ctx.newPage();
  await p.goto("https://conflora.test/", { waitUntil: "networkidle" });
  await click(p, "rain");
  await click(p, "clear-plan");
  check(
    (await p.locator('[name="area"]').inputValue()) === "",
    "Clear failed with denied storage",
  );
  await ctx.close();
});
await test("Versão V7 original preservada e comparação visual na mesma resolução", async () => {
  const old = await context.newPage();
  await old.goto(
    "https://conflora.test/original/CONFLORA_LIVING_LANDSCAPE_V7.html",
    { waitUntil: "networkidle" },
  );
  await old.screenshot({ path: path.join(out, "13-original-v7-desktop.png") });
  await old.close();
  const originals = await fs.readdir(path.join(project, "public/original"));
  for (const n of originals) {
    const a = await fs.readFile(path.join(project, "public/original", n));
    const b = await fs.readFile(path.join(project, "dist/original", n));
    check(hash(a) === hash(b), `Original changed ${n}`);
  }
});
await test("Zero exceções não tratadas nas jornadas principais", async () =>
  check(errors.length === 0, errors.join("\n")));
const report = {
  generatedAt: new Date().toISOString(),
  browser: await browser.version(),
  environment:
    "Linux container; Chromium headless; viewport emulation, not physical devices",
  method:
    "Production build served by Playwright route.fulfill from dist at an isolated HTTPS test origin. Managed preview relay unavailable.",
  results,
  errors,
  accessibility,
  limitations: [
    "Not a complete WCAG 2.2 AA audit",
    "No Safari or Firefox tests",
    "No physical mobile devices",
    "No field hydrology validation",
    "No Core Web Vitals field measurement",
  ],
};
await fs.writeFile(
  path.join(out, "results.json"),
  JSON.stringify(report, null, 2),
);
console.log(
  JSON.stringify({
    passed: results.filter((x) => x.status === "passed").length,
    failed: results.filter((x) => x.status === "failed").length,
    output: out,
  }),
);
await browser.close();
process.exitCode = results.some((x) => x.status === "failed") ? 1 : 0;

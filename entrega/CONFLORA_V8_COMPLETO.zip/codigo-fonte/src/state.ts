export type Lang = "pt" | "en";
export type Solution = "garden" | "strip" | "swale" | "permeable";
export type Soil = "unknown" | "draining" | "slow";
export type Surface = "paved" | "bare" | "grass";
export interface Plan {
  country: "BR" | "US";
  property: "home" | "school" | "rural";
  area: string;
  source: "roof" | "yard" | "path" | "field";
  soil: Soil;
  slope: "unknown" | "flat" | "steep";
  sun: "unknown" | "shade" | "mixed" | "sunny";
  moisture: "unknown" | "dry" | "variable" | "wet";
  goal: "understand" | "runoff" | "biodiversity" | "learn";
  risks: string[];
  solution: Solution;
}
export interface State {
  lang: Lang;
  rain: number;
  solution: Solution;
  soil: Soil;
  surface: Surface;
  compare: boolean;
  split: number;
  xray: boolean;
  flow: boolean;
  paused: boolean;
  dusk: boolean;
  planting: boolean;
  plants: { x: number; z: number }[];
  layer: number;
  plan: Plan;
  step: number;
  report: boolean;
  feedback: { score: string; comment: string };
}
const initialPlan: Plan = {
  country: "BR",
  property: "home",
  area: "15",
  source: "roof",
  soil: "unknown",
  slope: "unknown",
  sun: "unknown",
  moisture: "unknown",
  goal: "understand",
  risks: ["unknown"],
  solution: "garden",
};
export const state: State = {
  lang: "pt",
  rain: 0,
  solution: "garden",
  soil: "unknown",
  surface: "paved",
  compare: false,
  split: 50,
  xray: false,
  flow: true,
  paused: false,
  dusk: false,
  planting: false,
  plants: [],
  layer: 0,
  plan: { ...initialPlan },
  step: 0,
  report: false,
  feedback: { score: "", comment: "" },
};
export const storageKey = "conflora-atelier-v8";
export function restore() {
  try {
    const d = JSON.parse(localStorage.getItem(storageKey) || "null");
    if (d) {
      if (["pt", "en"].includes(d.lang)) state.lang = d.lang;
      const p = d.plan;
      if (p && typeof p === "object") {
        const enums: Record<string, string[]> = {
          country: ["BR", "US"],
          property: ["home", "school", "rural"],
          source: ["roof", "yard", "path", "field"],
          soil: ["unknown", "draining", "slow"],
          slope: ["unknown", "flat", "steep"],
          sun: ["unknown", "shade", "mixed", "sunny"],
          moisture: ["unknown", "dry", "variable", "wet"],
          goal: ["understand", "runoff", "biodiversity", "learn"],
          solution: ["garden", "strip", "swale", "permeable"],
        };
        for (const [k, vals] of Object.entries(enums))
          if (vals.includes(p[k]))
            (state.plan as unknown as Record<string, unknown>)[k] = p[k];
        if (typeof p.area === "string" && p.area.length < 20)
          state.plan.area = p.area;
        if (Array.isArray(p.risks)) {
          const r = p.risks.filter(
            (v: unknown) =>
              typeof v === "string" &&
              ["well", "pollution", "house", "none", "unknown"].includes(
                v as string,
              ),
          );
          if (r.length) state.plan.risks = r;
        }
      }
      state.solution = state.plan.solution;
      state.soil = state.plan.soil;
    }
  } catch {
    /* Storage is optional. */
  }
}
export function persist() {
  try {
    localStorage.setItem(
      storageKey,
      JSON.stringify({ lang: state.lang, plan: state.plan }),
    );
  } catch {
    /* Private browsing or quota must not prevent use. */
  }
}
export function riskReasons(p = state.plan) {
  return [
    ...p.risks.filter((x) => x !== "none"),
    ...(p.slope !== "flat" ? ["slope"] : []),
    ...(p.soil !== "draining" ? ["soil"] : []),
  ];
}
export function escapeHtml(s: unknown) {
  return String(s).replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ]!,
  );
}

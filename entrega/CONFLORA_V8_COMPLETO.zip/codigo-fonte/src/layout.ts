import { state, type Solution, type Soil, type Surface } from "./state";
import { t, sources } from "./content";
import { logo, icon, soilDiagram } from "./diagrams";
const solutionIds: Solution[] = ["garden", "strip", "swale", "permeable"];
function action(name: string, text: string, ic = "", cls = "") {
  return `<button type="button" data-action="${name}" class="${cls}">${ic ? icon(ic) : ""}<span>${text}</span></button>`;
}
function header() {
  const l = t();
  return `<a href="#explore" class="skip-link">${l.skip}</a><header class="header"><a class="brand" href="#top" aria-label="CONFLORA · ${l.atelier}">${logo}<span>CONFLORA<small>${l.atelier}</small></span></a><nav aria-label="${state.lang === "pt" ? "Navegação principal" : "Main navigation"}"><a href="#explore">${l.navExplore}</a><a href="#anatomy">${l.navSoil}</a><a href="#kit">${l.navKit}</a></nav><div class="header-right"><div class="language" role="group" aria-label="${state.lang === "pt" ? "Idioma" : "Language"}"><button data-action="lang" data-lang="pt" aria-pressed="${state.lang === "pt"}" lang="pt-BR">PT</button><span>/</span><button data-action="lang" data-lang="en" aria-pressed="${state.lang === "en"}" lang="en">EN</button></div><a class="header-plan" href="#planner">${l.navPlan}${icon("arrow")}</a></div></header>
`;
}

function introduction() {
  const l = t();
  return `<main id="top"><section class="intro wrap"><div><p class="eyebrow"><span class="live-dot"></span>${l.project}</p><h1>${l.headline}</h1></div><div class="intro-copy"><p>${l.intro}</p><a href="#explore" class="text-link">${l.scroll}<span>↘</span></a></div><div class="intro-seal" aria-label="${state.lang === "pt" ? "ODS 6, água limpa e saneamento" : "SDG 6, clean water and sanitation"}"><span>ODS / SDG</span><strong>06</strong><span>BR ↔ US</span></div></section>
`;
}

function experience() {
  const l = t();
  return `<section id="explore" class="experience wrap" aria-labelledby="lab-heading"><div class="lab-shell"><aside class="lab-controls"><p class="eyebrow">${l.labKicker}</p><h2 id="lab-heading">${l.labTitle}</h2><p class="lab-intro">${l.labIntro}</p><div class="rain-control"><div class="control-heading"><label for="rain">${l.rain}</label><output for="rain" id="rain-value"></output></div><input type="range" id="rain" min="0" max="3" step="1" value="${state.rain}" aria-describedby="rain-tip"><div class="range-ticks" aria-hidden="true"><span>○</span><span>╵</span><span>╵</span><span>☂</span></div><small id="rain-tip">${l.rainTip}</small><button class="rain-button" data-action="rain">${icon("rain")}<span id="rain-button-text">${l.startRain}</span></button></div><details class="conditions"><summary>${l.conditions}<span>+</span></summary><label class="field">${l.surface}<select id="surface">${(["paved", "bare", "grass"] as Surface[]).map((v) => `<option value="${v}" ${v === state.surface ? "selected" : ""}>${l[v]}</option>`).join("")}</select></label><label class="field">${l.soil}<select id="soil">${(["unknown", "draining", "slow"] as Soil[]).map((v) => `<option value="${v}" ${v === state.soil ? "selected" : ""}>${l[v]}</option>`).join("")}</select></label><small>${l.soilNote}</small></details><button class="guide-link" data-action="guide">${icon("play")}${l.guide}<span>↗</span></button></aside>
<div class="landscape-panel"><div class="scene-top"><span class="eyebrow">${l.sceneCode}</span><div class="scene-tools">${action("dusk", l.dusk, "sun", "icon-button")}${action("pause", l.pause, "pause", "icon-button")}${action("fullscreen", l.fullscreen, "expand", "icon-button")}</div></div><div id="landscape-slot"></div><div class="scene-labels" aria-hidden="true"><span id="before-label">${l.before}</span><span id="after-label">${l.after}</span></div><div class="compare-track" id="compare-track" hidden><div id="divider" class="compare-divider"><span>↔</span></div><input type="range" id="split" min="0" max="100" value="${state.split}" aria-label="${l.compareLabel}" aria-describedby="compare-hint"></div><div class="scene-bottom"><span class="north" aria-hidden="true">↑ N</span><div class="view-toggles">${action("compare", l.compare, "compare", "view-button")}${action("xray", l.xray, "layers", "view-button")}${action("flow", l.paths, "flow", "view-button")}</div><button class="icon-button" data-action="reset" aria-label="${l.reset}">${icon("reset")}<span>${l.reset}</span></button></div><div class="soil-scene-caption" id="soil-caption" hidden>${l.sectionNote}<br><span id="hypothesis-label">${l.hypothesis}</span></div></div></div>
<div id="guide" class="guide" hidden></div><p id="compare-hint" class="compare-hint" hidden>${l.compareHint}</p><div class="scene-footnote"><span><span class="status-dot"></span>${l.qualitative}</span><span>${l.notModel}</span></div>
<div class="solution-picker"><p class="eyebrow">${l.solutionKicker}</p><div class="solution-row">${solutionIds.map((s, i) => `<button type="button" class="solution-choice" data-action="solution" data-value="${s}" aria-pressed="${state.solution === s}"><span class="solution-number">0${i + 1}</span><span><strong>${l[s]}</strong><small>${l[(s + "Sub") as keyof typeof l]}</small></span><span class="solution-arrow">↗</span></button>`).join("")}</div></div><div class="observation"><div><span class="eyebrow">${l.observation}</span><h3 id="observation-title"></h3></div><div><p id="solution-description"></p><p class="water-observation" id="water-observation" aria-live="polite"></p><details class="plant-details"><summary>${icon("plus")}${l.place}</summary><p>${l.placeHint}</p><div class="plant-actions">${action("plant-mode", l.place, "leaf", "text-link")}${action("add-plant", l.addPlant, "plus", "text-link")}${action("clear-plants", l.removePlants, "reset", "text-link")}<output id="plant-count"></output></div></details></div></div><div class="carry-row"><p>${l.carryNote}</p><button class="button dark" data-action="carry">${l.carry}${icon("arrow")}</button></div></section>
`;
}

function anatomy() {
  const l = t();
  return `<section id="anatomy" class="anatomy"><div class="wrap"><div class="section-intro"><div><p class="eyebrow">${l.soilKicker}</p><h2>${l.soilTitle}</h2></div><p>${l.soilIntro}</p></div><div class="anatomy-grid"><div class="soil-illustration" id="soil-illustration" data-layer="${state.layer}">${soilDiagram()}<p>${l.sectionNote}</p></div><div class="layer-list">${l.layerNames.map((s, i) => `<div class="layer-item"><button data-action="layer" data-value="${i}" aria-expanded="${i === state.layer}" aria-controls="layer-detail-${i}"><span>0${i + 1}</span><span>${s}</span><span class="layer-plus">${i === state.layer ? "−" : "+"}</span></button><div id="layer-detail-${i}" class="layer-detail" ${i !== state.layer ? "hidden" : ""}><span>${l.layerShort[i]}</span><p>${l.layerTexts[i]}</p></div></div>`).join("")}</div></div></div></section>
`;
}

function planner() {
  const l = t();
  return `<section id="planner" class="planner wrap"><div class="section-intro"><div><p class="eyebrow">${l.planKicker}</p><h2>${l.planTitle}</h2></div><p>${l.planIntro}</p></div><div class="planner-grid"><aside class="planner-aside"><ol class="step-list">${l.stepNames.map((s, i) => `<li data-step="${i}"><button data-action="step" data-value="${i}"><span>0${i + 1}</span>${s}</button></li>`).join("")}</ol><p class="privacy-note">${icon("info")}${l.saved}</p><button class="text-link delete-link" data-action="clear-plan">${l.clear}</button><div class="plan-preview" id="plan-preview"><span class="eyebrow">${l.selectedSolution}</span><strong>${l[state.plan.solution]}</strong><span class="preview-line"></span></div></aside><div id="planner-body" class="planner-body"></div></div><section id="report" class="report" hidden aria-labelledby="report-title"></section></section>
`;
}

function kit() {
  const l = t();
  return `<section id="kit" class="kit-section"><div class="wrap"><div class="kit-layout"><div class="kit-heading"><p class="eyebrow">${l.kitKicker}</p><h2>${l.kitTitle}</h2><p>${l.kitIntro}</p><div class="kit-mark" aria-hidden="true">${logo}<span>CONFLORA<br>× CLEAN WATER KIT</span></div></div><div class="kit-details"><span class="development"><span class="live-dot"></span>${l.kitStatus}</span><p>${l.kitText}</p><button class="button lime" data-action="export-kit">${icon("download")}${l.kitTransfer}</button><small>${l.kitLocal}</small><details class="notebook"><summary>${icon("book")}${l.kitLearn}<span>+</span></summary><ol>${l.kitTasks.map((s) => `<li>${s}</li>`).join("")}</ol></details></div></div></div></section>
`;
}

function research() {
  const l = t();
  return `<section class="research wrap"><div class="research-heading"><h2>${l.references}</h2><p>${l.refIntro}</p></div><div class="reference-list">${sources.map((url, i) => `<a href="${url}" target="_blank" rel="noopener noreferrer"><span class="reference-index">0${i + 1}</span><strong>${l.refTitles[i]}</strong><span>${l.refBodies[i]}</span>${icon("external")}</a>`).join("")}</div></section></main>
`;
}

function footer() {
  const l = t();
  return `<footer class="footer wrap"><div class="footer-main"><a class="brand" href="#top">${logo}<span>CONFLORA<small>${l.atelier}</small></span></a><p>${l.footer}</p><span>BRaVE 2026<br>BR ↔ US</span></div><p class="footer-context">${l.footerContext}</p><div class="footer-bottom"><p>${l.footerNote}</p><div><a href="./entrega/index.html">${l.deliverables} ↗</a><a href="./original/CONFLORA_LIVING_LANDSCAPE_V7.html" target="_blank" rel="noopener">${l.legacy} ↗</a></div></div></footer><div class="toast" id="toast" role="status" aria-live="polite"></div>`;
}

export function renderLayout() {
  return (
    header() +
    introduction() +
    experience() +
    anatomy() +
    planner() +
    kit() +
    research() +
    footer()
  );
}

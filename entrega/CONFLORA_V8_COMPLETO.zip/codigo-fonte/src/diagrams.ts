import { state, type Solution } from "./state";
import { t } from "./content";
export const logo = `<svg viewBox="0 0 80 80" aria-hidden="true"><path d="M63 17C48 5 29 9 17 23 4 39 7 61 22 71c13 9 31 7 42-5-17 7-34 2-40-11-6-14 1-29 14-35 8-4 16-4 25-3Z" fill="currentColor"/><path d="M20 53c9-13 22-17 43-13-10 4-15 10-22 17-7 7-14 7-21-4Z" fill="#84CAC8"/><path d="M20 53c13-17 26-20 43-18" stroke="#0B241D" stroke-width="4" fill="none" stroke-linecap="round"/></svg>`;
export function icon(name: string) {
  const paths: Record<string, string> = {
    rain: '<path d="m7 15-1 3m6-3-1 3m6-3-1 3M5 12a4 4 0 0 1 1-8 6 6 0 0 1 11 1 3.5 3.5 0 0 1 1 7Z"/>',
    arrow: '<path d="M4 12h15m-6-6 6 6-6 6"/>',
    chevron: '<path d="m9 5 7 7-7 7"/>',
    compare: '<path d="M12 3v18M4 6h4v12H4zm12 0h4v12h-4z"/>',
    layers: '<path d="m3 8 9-5 9 5-9 5ZM3 13l9 5 9-5M3 18l9 5 9-5"/>',
    expand: '<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 1v2m0 18v2M1 12h2m18 0h2M4 4l2 2m12 12 2 2M4 20l2-2M18 6l2-2"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    play: '<path d="m8 4 12 8-12 8Z"/>',
    reset: '<path d="M4 10a8 8 0 1 1 2 8M4 4v6h6"/>',
    plus: '<path d="M12 4v16M4 12h16"/>',
    close: '<path d="m5 5 14 14M5 19 19 5"/>',
    leaf: '<path d="M4 20 17 7M5 16C1 5 10 2 21 3c0 12-4 19-15 15"/>',
    download: '<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
    print: '<path d="M6 8V3h12v5M6 17H3V9h18v8h-3M6 14h12v7H6Z"/>',
    check: '<path d="m4 12 5 5L20 6"/>',
    flow: '<path d="M3 6c8 0 4 12 12 12h5m-5-5 5 5-5 5M3 12c5 0 3-7 9-7h8m-4-4 4 4-4 4"/>',
    external: '<path d="M9 4H4v16h16v-5M12 3h9v9M10 14 21 3"/>',
    book: '<path d="M12 5C8 2 4 3 2 4v15c3-1 7-1 10 2 3-3 7-3 10-2V4c-2-1-6-2-10 1Zm0 0v16"/>',
    menu: '<path d="M3 7h18M3 17h18"/>',
    copy: '<rect x="8" y="8" width="13" height="13" rx="1"/><path d="M16 8V3H3v13h5"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-11v1"/>',
  };
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.leaf}</svg>`;
}
export function planDiagram(
  solution: Solution,
  live = false,
  baseline = false,
) {
  const l = t();
  const wet = live && state.rain > 0;
  let intervention = "";
  if (solution === "garden")
    intervention =
      '<ellipse cx="345" cy="228" rx="94" ry="65" fill="#8b9b73"/><ellipse cx="345" cy="228" rx="73" ry="44" fill="#6f8056"/>';
  if (solution === "strip")
    intervention =
      '<rect x="245" y="255" width="196" height="52" rx="20" fill="#7c9265"/>';
  if (solution === "swale")
    intervention =
      '<path d="M360 110Q280 175 355 230T345 320" stroke="#85966d" stroke-width="50" fill="none"/>';
  if (solution === "permeable") {
    intervention =
      '<rect x="251" y="158" width="190" height="148" rx="4" fill="url(#pavers)"/>';
  }
  let plants = "";
  if (solution !== "permeable")
    for (let i = 0; i < 42; i++) {
      const a = i * 2.4,
        r = Math.sqrt((i + 0.5) / 42),
        x =
          solution === "garden"
            ? 345 + Math.cos(a) * 83 * r
            : solution === "strip"
              ? 253 + (i % 14) * 13
              : 350 + Math.sin(i * 0.13) * 29,
        y =
          solution === "garden"
            ? 228 + Math.sin(a) * 55 * r
            : solution === "strip"
              ? 268 + Math.floor(i / 14) * 13
              : 117 + i * 4.7;
      plants += `<g transform="translate(${x} ${y}) rotate(${i * 43})"><path d="M0-9Q8-5 0 5-8-4 0-9Z" fill="${i % 3 ? "#355c40" : "#c5cd96"}"/><path d="M-8 0Q-2-8 5 0-3 6-8 0Z" fill="#668657"/></g>`;
    }
  if (baseline) {
    intervention = "";
    plants = "";
  }
  return `<svg viewBox="0 0 500 370" role="img" aria-label="${l.concept}"><defs><pattern id="pavers" width="28" height="23" patternUnits="userSpaceOnUse"><rect width="25" height="20" fill="#c5c1ae"/></pattern><pattern id="papergrid" width="25" height="25" patternUnits="userSpaceOnUse"><path d="M25 0H0V25" fill="none" stroke="#0b241d" opacity=".06"/></pattern></defs><rect width="500" height="370" fill="#edede2"/><rect width="500" height="370" fill="url(#papergrid)"/><rect x="50" y="40" width="400" height="290" fill="#b7be9e" stroke="#56725a" stroke-width="1"/><rect x="65" y="170" width="168" height="147" fill="${live && state.surface === "bare" ? "#b49a7b" : live && state.surface === "grass" ? "#95a67c" : "#d2ccbb"}"/><rect x="65" y="55" width="170" height="107" fill="#e3dbc8" stroke="#987a5a"/><path d="M61 51h178v115H61Z M150 51v115" stroke="#a87354" fill="#c29373" stroke-width="2"/><rect x="65" y="170" width="170" height="18" fill="#937d5d"/>${intervention}${plants}<path d="M226 164Q240 210 279 222T340 236M384 270l28 42" stroke="${wet ? "#378b99" : "#497b80"}" stroke-width="${wet ? "4" : "2"}" fill="none" stroke-dasharray="6 7"/><path d="m405 305 8 8 1-12" stroke="#497b80" stroke-width="2" fill="none"/><circle cx="406" cy="91" r="26" fill="#6f8559"/><circle cx="410" cy="91" r="18" fill="#8b9d6c"/><path d="M27 61V34l-5 9m5-9 5 9" stroke="#0b241d" fill="none"/><text x="22" y="27" fill="#0b241d" font-size="11">N</text><text x="50" y="354" fill="#395348" font-family="sans-serif" font-size="10">${l.sectionNote}</text>${live && state.xray ? '<path d="M50 285h400v45H50Z" fill="#9b7f59" opacity=".8"/><path d="M50 308h400" stroke="#c8aa7e" stroke-width="10"/>' : ""}</svg>`;
}
export function soilDiagram() {
  const l = t();
  return `<svg class="soil-svg" viewBox="0 0 680 430" role="img" aria-label="${l.sectionNote}"><defs><pattern id="soilgrain" width="27" height="23" patternUnits="userSpaceOnUse"><circle cx="6" cy="8" r="1.3" fill="#50432e" opacity=".3"/><circle cx="20" cy="20" r="2" fill="#f8e3b7" opacity=".4"/></pattern><pattern id="gravel" width="36" height="23" patternUnits="userSpaceOnUse"><path d="m2 5 11-3 7 7-8 8-12-4Zm23 9 8-5 4 8-6 5Z" fill="#b7b5a0" stroke="#858878" stroke-width="1"/></pattern></defs><g class="soil-layer soil-layer-3"><path d="M40 299H640v71H40Z" fill="#7d8470"/><path d="M40 301H640v67H40Z" fill="url(#gravel)"/></g><g class="soil-layer soil-layer-2"><path d="M40 215q175-14 300 29 130-43 300-29v88H40Z" fill="#ba9d73"/><path d="M40 215q175-14 300 29 130-43 300-29v88H40Z" fill="url(#soilgrain)"/></g><g class="soil-layer soil-layer-1"><path d="M40 202q170-11 300 26 130-37 300-26v16q-165-14-300 31-131-45-300-31Z" fill="#75573d"/><g stroke="#ae8b5e" stroke-width="3"><path d="m52 206 25 6m18-8 19 6m18-6 30 7m22-1 21 8m21-2 26 10m205-9 25-8m25-5 23 2m24-1 28-2m22 5 23-4"/></g></g><g class="soil-layer soil-layer-0" stroke="#4d7045" fill="none" stroke-linecap="round"><path d="M120 204q12-45-2-85m2 63q-34-27-42-48m42 29q29-23 33-51M216 215q1-68-9-102m8 69q-36-41-36-59m36 70q31-37 43-65M453 215q-5-66 11-112m-10 91q-33-22-37-60m39 39q21-28 30-29M557 207q5-51 20-97m-16 75q-33-21-35-47" stroke-width="3"/><g fill="#73895a" stroke="none"><path d="M116 159q-34-14-28-42 29 6 28 42Zm7-11q11-34 39-38-3 31-39 38M211 161q-37-16-35-43 27 8 35 43Zm9 20q9-42 39-50-1 31-39 50M458 163q-31-17-31-46 30 14 31 46m3-24q6-35 29-44 1 29-29 44M560 166q-30-9-35-38 30 9 35 38m7-28q4-32 25-39 5 27-25 39"/></g><g fill="#c1b789" stroke="#8d875b"><circle cx="207" cy="111" r="9"/><circle cx="465" cy="101" r="8"/><circle cx="578" cy="109" r="7"/></g><g stroke="#6a5c3c" stroke-width="1.3" opacity=".7"><path d="m120 217-5 30-17 14m18-18 15 22m-11-17-4 37m99-52-3 30-22 19m24-22 20 26m221-53-8 39-23 20m24-23 13 25m100-72-12 40-13 20m15-25 18 12"/></g></g><g class="soil-layer soil-layer-4"><path d="M329 219q80-7 141-12t130-19" stroke="#70b9bc" fill="none" stroke-width="4" stroke-dasharray="8 8"/><path d="m586 179 16 8-12 13" stroke="#70b9bc" fill="none" stroke-width="4"/></g><path d="M299 220q40 19 81 0" fill="#84cac8" opacity=".65"/><g fill="none" stroke="#497f82" stroke-width="2" stroke-dasharray="5 8"><path d="M307 255v87m35-83v83m35-87v87"/></g><path d="M40 370H640" stroke="#314f3c"/><text x="40" y="405" font-size="11" fill="#4b6152" font-family="sans-serif">${l.hypothesis}</text><g font-family="sans-serif" font-size="11" fill="#213b2b"><text x="20" y="154">01</text><text x="20" y="209">02</text><text x="20" y="269">03</text><text x="20" y="338">04</text><text x="606" y="166">05</text></g></svg>`;
}
